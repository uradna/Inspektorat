<?php $attributes = $attributes->exceptProps(['value', 'untuk']); ?>
<?php foreach (array_filter((['value', 'untuk']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<label <?php echo e($attributes->merge(['class' => 'form-label fs-7'])); ?> for="<?php echo e($untuk); ?>">
    <?php echo e($value ?? $slot); ?>

</label>
<input type="text">
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/components/labelx.blade.php ENDPATH**/ ?>