<div class="card-header bg-dark">
    <a href="<?php echo e(route('login')); ?>">
        <img src="<?php echo e(asset('img/logo.png')); ?>" style="max-height: 40px;">
    </a>
</div>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/components/guest-logo.blade.php ENDPATH**/ ?>