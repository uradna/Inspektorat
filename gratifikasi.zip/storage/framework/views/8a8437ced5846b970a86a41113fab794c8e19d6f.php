<?php if (isset($component)) { $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminwideLayout::class, []); ?>
<?php $component->withName('superadminwide-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .file-custom {
                padding-top: 2.4rem !important;
                padding-bottom: 2.3rem !important;
                padding-left: 1.8rem !important;
            }

            .file-custom:focus {
                outline: none;
            }

        </style>
        <?php if(!app('mobile-detect')->isMobile()) : ?>
        <style>
            table.dataTable>tbody>tr.child span.dtr-title {
                min-width: 180px !important;
                max-width: 700px !important;
            }

        </style>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Data Pegawai')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.pegawai')); ?>">Data Pegawai</a></li>
        <li class="breadcrumb-item active"><?php echo e(truncate($pd)); ?></li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Pegawai')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Edit Data Pegawai - <?php echo e($pd); ?></h4>


                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        
                                        <th data-priority="0">Nama</th>
                                        <th>NIP</th>
                                        <th>No. HP</th>
                                        
                                        <th>Jabatan</th>
                                        <th>Pangkat/golongan</th>
                                        <th>Satker</th>
                                        <th data-priority="1" class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="main">

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('components.superadmin.modal.pegawai-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.superadmin.modal.pegawai-del', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.superadmin.modal.pegawai-password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.superadmin.modal.pegawai-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                    dom: '<"container-fluid"<"row"<"col ps-0"B><"col pe-0"f>>>rtip',
                    <?php else: ?>
                    dom: 'Bfrtip',
                    <?php endif; ?>
                    ajax: "<?php echo e(route('superadmin.pegawai.pd.ajax', $pd)); ?>",
                    dataSrc: 'data',
                    columnDefs: [{
                            data: 'name',
                            targets: 0
                        },
                        {
                            data: 'nip',
                            targets: 1
                        },
                        {
                            data: 'phone',
                            targets: 2
                        },
                        {
                            data: 'jabatan',
                            targets: 3
                        },
                        {
                            data: 'pangkat',
                            targets: 4
                        },
                        {
                            data: 'satker',
                            targets: 5
                        },
                        {
                            data: null,
                            className: "text-end",
                            defaultContent: '<button type="button" class="btn btn-success btn-xsm ebutton" data-bs-toggle="modal" data-bs-target="#edit"> <i class="uil-pen"></i> edit </button> <button type="button" class="btn btn-info btn-xsm pbutton" data-bs-toggle="modal" data-bs-target="#pass"><i class="uil-key-skeleton"></i> password </button> <button type="button" class="btn btn-danger btn-xsm dbutton" data-bs-toggle="modal" data-bs-target="#del"> <i class="uil-trash-alt"></i> hapus </button>',
                            targets: 6
                        }
                    ],
                    lengthChange: !1,
                    buttons: [{
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            text: '<i class="uil-arrow-left"></i>Kembali',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="uil-arrow-left"></i>',
                            className: 'mb-1',
                            <?php endif; ?>
                            action: function(e, dt, node, config) {
                                window.open(
                                    "<?php echo e(route('superadmin.pegawai')); ?>",
                                    "_self");
                            }
                        },
                        {
                            extend: 'colvis',
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            text: 'Kolom',
                            className: 'btn-rounded-e',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-table-eye"></i>',
                            className: 'mb-1',
                            <?php endif; ?>
                        },
                        {
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            text: '<i class="mdi mdi-plus-circle me-1"></i> Tambah Pegawai',
                            className: 'add-bt ms-2 btn-rounded btn-success',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-plus-circle"></i>',
                            className: 'mb-1 add-bt btn-success',
                            <?php endif; ?>
                        },
                    ],
                    language: {
                        lengthMenu: "Menampilkan _MENU_ pegawai per halaman",
                        <?php if(!app('mobile-detect')->isMobile()) : ?>
                        search: "Pencarian",
                        <?php endif; ?>
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        search: "",
                        searchPlaceholder: "Pencarian",
                        <?php endif; ?>
                        info: "Menampilkan data ke _START_ sampai _END_ dari _TOTAL_ total data",
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    },
                    deferRender: true,
                });
                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                });
                a.buttons('.add-bt')
                    .nodes()
                    .attr('data-bs-toggle', 'modal');
                a.buttons('.add-bt')
                    .nodes()
                    .attr('data-bs-target', '#add');

                a.on('click', '.pbutton', function(e) {

                    <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                    let id = $(this).closest('tr').attr('id');
                    <?php else: ?>
                    let id = $(this).closest('tr').prev().attr('id');
                    <?php endif; ?>
                    let all_data = a.rows().data();
                    let result = $.grep(all_data, function(e) {
                        return e.DT_RowId == id;
                    });
                    let data = result[0];

                    $('#p-id').val(data['id']);
                    $('#p-name').val(data['name']);
                    $('#p-nip').val(data['nip']);
                    $('#password').val('');
                    $('#confirmPassword').val('');
                });

                a.on('click', '.ebutton', function(e) {

                    <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                    let id = $(this).closest('tr').attr('id');
                    <?php else: ?>
                    let id = $(this).closest('tr').prev().attr('id');
                    <?php endif; ?>
                    let all_data = a.rows().data();
                    let result = $.grep(all_data, function(e) {
                        return e.DT_RowId == id;
                    });
                    let data = result[0];

                    $('.e-id').val(data['id']);
                    $('.e-name').val(data['name']);
                    $('.e-nip').val(data['nip']);
                    $('.e-email').val(data['email']);
                    $('.e-phone').val(data['phone']);
                    $('.e-pd').val(data['pd']);
                    $('.e-satker').val(data['satker']);
                });

                a.on('click', '.dbutton', function(e) {

                    <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                    let id = $(this).closest('tr').attr('id');
                    <?php else: ?>
                    let id = $(this).closest('tr').prev().attr('id');
                    <?php endif; ?>
                    let all_data = a.rows().data();
                    let result = $.grep(all_data, function(e) {
                        return e.DT_RowId == id;
                    });
                    let data = result[0];

                    $('.d-id').val(data['id']);
                    $('.d-name').val(data['name']);
                    $('.d-nip').val(data['nip']);
                    $('#alasan').val('');
                    $('.d-file').val('');
                });

            });

        </script>

        <?php if($errors->any()): ?>
            <script type="text/javascript">
                Swal.fire({
                    title: 'Ops...',
                    html: 'Ada sesuatu yang salah.<br>Pastikan form sudah terisi semua dengan benar.',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#fa5c7c'
                })

            </script>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4)): ?>
<?php $component = $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4; ?>
<?php unset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/superadmin/pegawaipd.blade.php ENDPATH**/ ?>