<div class="logo-topbar">
    <!-- Logo light -->
    <a href="<?php echo e(route('home')); ?>" class="logo-light">
        <span class="logo-lg">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logoxx" height="50">
        </span>
    </a>

    <!-- Logo Dark -->
    <a href="<?php echo e(route('home')); ?>" class="logo-dark">
        <span class="logo-lg">
            <img src="<?php echo e(asset('img/logo-dark.png')); ?>" alt="dark logoxx" height="50">
        </span>
    </a>
</div>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/components/user/logo-detached.blade.php ENDPATH**/ ?>