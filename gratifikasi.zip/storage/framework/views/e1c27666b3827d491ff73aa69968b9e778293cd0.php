<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title><?php echo e($title); ?></title>
    <meta content="<?php echo e($description); ?>" name="description" />
    <style>
        @page  {
            margin: 25px 35px;
        }

        body {
            margin: 25px 35px;
        }

        table {
            margin-top: 10px;
            margin-bottom: 20px;
        }

        h4 {
            font-size: 1.2rem;
            margin-bottom: 45px;
        }

        td,
        th {
            padding: 3px;
        }

        .tabel,
        .tabel>tbody>tr>th,
        .tabel>tbody>tr>td {
            border: solid 1px #000;
        }
    </style>
</head>

<body>
    <div>
        <h4 align="center"><u>SURAT PERNYATAAN GRATIFIKASI</u></h4>
    </div>
    <div> Yang bertanda tangan di bawah ini: </div>
    <table style="margin-left:30px;">
        <tbody>
            <tr>
                <td>Nama</td>
                <td>:</td>
                <td><?php echo e($name); ?></td>
            </tr>
            <tr>
                <td>NIP</td>
                <td>:</td>
                <td><?php echo e($nip); ?></td>
            </tr>
            <tr>
                <td>Pangkat</td>
                <td>:</td>
                <td><?php echo e($pangkat); ?></td>
            </tr>
            <tr>
                <td>Jabatan</td>
                <td>:</td>
                <td><?php echo e($jabatan); ?></td>
            </tr>
            <tr>
                <td>Asal Perangkat Daerah </td>
                <td>:</td>
                <td><?php echo e($pd); ?></td>
            </tr>
            <tr>
                <td>Alamat Email</td>
                <td>:</td>
                <td><?php echo e($email); ?></td>
            </tr>
            <tr>
                <td>Nomor HP</td>
                <td>:</td>
                <td><?php echo e($phone); ?></td>
            </tr>
        </tbody>
    </table>

    <div>Menyatakan bahwa pada periode <?php echo e($periode); ?>, saya:</div>
    
    <table style="margin-left:30px">
        <tbody>
            <tr>
                <td><strong>
                        <input type="checkbox" <?php echo e($point[0] == '1' ? 'checked="checked"' : ''); ?> />
                    </strong></td>
                <td><strong>Tidak pernah menerima gratifikasi</strong></td>
            </tr>
            <tr>
                <td><strong>
                        <input type="checkbox" <?php echo e($point[1] == '1' ? 'checked="checked"' : ''); ?> />
                    </strong></td>
                <td><strong>Menerima gratifikasi dan telah melaporkannya kepada UPG/KPK</strong></td>
            </tr>
            <tr>
                <td><strong>
                        <input type="checkbox" <?php echo e($point[2] == '1' ? 'checked="checked"' : ''); ?> />
                    </strong></td>
                <td><strong>Menerima gratifikasi namun belum melaporkannya kepada UPG/KPK</strong></td>
            </tr>
        </tbody>
    </table>
    <?php if($lapor->count() != 0): ?>
        <div>Rincian penerimaan gratifikasi yang belum dilaporkan ke UPG/KPK</div>
        <table class="tabel" cellpadding="0" cellspacing="0">
            <tbody>
                <tr>
                    <th>Jenis</th>
                    <th>Bentuk</th>
                    <th>Nilai</th>
                    <th width="15%">Waktu</th>
                    <th>Nama Pemberi</th>
                    <th>Hubungan</th>
                    <th>Alasan</th>
                </tr>
                <?php $__currentLoopData = $lapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center"><?php echo e($l->jenis); ?></td>
                        <td align="center"><?php echo e($l->bentuk); ?></td>
                        <td align="center"><?php echo e(number_format($l->nilai, 0, ',', '.')); ?> </td>
                        <td align="center"><?php echo e(konversiTanggalPendek($l->tanggal)); ?></td>
                        <td align="center"><?php echo e($l->pemberi); ?></td>
                        <td align="center"><?php echo e($l->hubungan); ?></td>
                        <td align="center"><?php echo e($l->alasan); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <div>
        Demikian Surat Pernyataan ini saya buat dengan sebenar-benarnya, apabila dikemudian hari ada penerimaan
        gratifikasi yang sengaja tidak saya laporkan atau dilaporkan tidak benar maka saya bersedia
        mempertanggungjawabkan secara hukum sesuai dengan peraturan perundang-undangan yang berlaku.</div>

    <table width="100%">
        <tbody>
            <tr>
                <td> </td>
                <td width="40%">
                    <div align="center">
                        <p>&nbsp;</p>
                        <p>Ponorogo, <?php echo e($tg_ttd); ?><br />
                            Yang Membuat Pernyataan<br />
                            <br />
                            <span style="color:#BBB">TTD</span><br />
                            <br />
                            <u><strong><?php echo e(strtoupper($name)); ?></strong>
                            </u>
                        </p>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/print.blade.php ENDPATH**/ ?>