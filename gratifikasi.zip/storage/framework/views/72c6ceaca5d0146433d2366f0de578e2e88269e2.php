<?php if (isset($component)) { $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminwideLayout::class, []); ?>
<?php $component->withName('superadminwide-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .file-custom {
                padding-top: 2.4rem !important;
                padding-bottom: 2.3rem !important;
                padding-left: 1.8rem !important;
            }

            .file-custom:focus {
                outline: none;
            }
        </style>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Data Pernyataan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.pernyataan')); ?>">Pernyataan</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.pernyataan.terakhir', $id)); ?>">Tahun
                <?php echo e($jadwal->tahun); ?> Semester <?php echo e($jadwal->semester); ?></a></li>
        <li class="breadcrumb-item active"><?php echo e(truncate($pd)); ?></li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Pernyataan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Data Pernyataan - Tahun <?php echo e($jadwal->tahun); ?> Semester
                            <?php echo e($jadwal->semester); ?> - <?php echo e($pd); ?></h4>

                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        
                                        <th data-priority="0">Nama</th>
                                        <th data-priority="3">NIP</th>
                                        <th>No. HP</th>
                                        <th>Jabatan</th>
                                        <th>Satker</th>
                                        <th>Pernyataan</th>
                                        <th data-priority="1">Status</th>
                                    </tr>
                                </thead>
                                <tbody id="main"> </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                    dom: '<"container-fluid"<"row"<"col ps-0"B><"col pe-0"f>>>rtip',
                    <?php else: ?>
                    dom: 'Bfrtip',
                    <?php endif; ?>
                    ajax: "<?php echo e(route('superadmin.pernyataan.terakhir.pd.ajax', [$id, $pd])); ?>",
                    dataSrc: 'data',
                    columnDefs: [{
                            data: 'name',
                            targets: 0,
                            render: function(data, type, row) {
                                let text = row.name;
                                if (row.tanya1 !== null && row.tanya2 !== null && row.tanya3 !== null) {
                                    if (row.tanya3 === 1) {
                                        text +=
                                            '<sup class="bg-danger ms-1 text-white rounded" style="padding:0.1em 0.6em; font-size:0.6rem;"><b>!</b></sup>';
                                    }
                                }
                                return text;
                            }
                        },
                        {
                            data: 'nip',
                            targets: 1,
                            render: function(data, type, row) {
                                return row.nip.substr(0, 8) + " " + row.nip.substr(8, 6) + " " + row.nip.substr(14, 1) + " " + row.nip.substr(15, 3);
                            }
                        },
                        {
                            data: 'phone',
                            targets: 2
                        },
                        {
                            data: 'jabatan',
                            targets: 3
                        },
                        {
                            data: 'satker',
                            targets: 4
                        },
                        {
                            data: 'tanya1',
                            // className: "text-end",
                            targets: 5,
                            render: function(data, type, row) {
                                let text = "";
                                if (row.tanya1 !== null && row.tanya2 !== null && row.tanya3 !== null) {
                                    if (row.tanya1 === 0) {
                                        text += '<i class="uil-times-square text-danger">Tidak</i> ';
                                    } else {
                                        text += '<i class="uil-check-square text-success">Ya</i> ';
                                    }
                                    if (row.tanya2 === 0) {
                                        text += '<i class="uil-times-square text-danger">Tidak</i> ';
                                    } else {
                                        text += '<i class="uil-check-square text-success">Ya</i> ';
                                    }
                                    if (row.tanya3 === 0) {
                                        text += '<i class="uil-times-square text-danger">Tidak</i> ';
                                    } else {
                                        text += '<i class="uil-check-square text-success">Ya</i> ';
                                    }
                                    return text;
                                } else {
                                    return "-";
                                }
                            }
                        },
                        {
                            data: 'pernyataan',
                            targets: 6,
                            render: function(data, type, row) {
                                let text = "";
                                let url = "../../../pernyataan/pdf/<?php echo e($jadwal->id); ?>/" + row.id;
                                if (row.pernyataan === 1) {
                                    text +=
                                        '<i class="mdi mdi-check btn btn-xsm btn-success pe-none fst-normal"> sudah  </i>';
                                    text +=
                                        ' <a href="' + url +
                                        '" class="btn btn-xsm btn-secondary"><i class="uil-down-arrow"></i> pdf </a> ';

                                    return text;
                                } else {
                                    return '<i class="mdi mdi-close btn btn-xsm btn-danger pe-none fst-normal"> <?php if(!app('mobile-detect')->isMobile()) : ?>belum <?php endif; ?> </i>';
                                }
                            }
                        }
                    ],
                    order: [
                        [6, 'desc']
                    ],
                    lengthChange: !1,
                    filter: !1,
                    searching: 1,
                    pageLength: 20,
                    info: !0,
                    buttons: [{
                        <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                        text: '<i class="uil-arrow-left"></i>Kembali',
                        <?php else: ?>
                        text: '<i class="uil-arrow-left"></i>',
                        className: 'mb-1',
                        <?php endif; ?>
                        action: function(e, dt, node, config) {
                            window.open("<?php echo e(route('superadmin.pernyataan.terakhir', $id)); ?>",
                                "_self");
                        }
                    }, {
                        extend: 'excel',
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        text: '<i class="mdi mdi-microsoft-excel"></i>',
                        className: 'mb-1',
                        <?php endif; ?>
                        title: 'Data Pernyataan - Tahun <?php echo e($jadwal->tahun); ?> Semester <?php echo e($jadwal->semester); ?> - <?php echo e($pd); ?>',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5]
                        }
                    }, {
                        extend: 'colvis',
                        <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                        text: 'Kolom',
                        <?php else: ?>
                        text: '<i class="mdi mdi-table-eye"></i>',
                        className: 'mb-1',
                        <?php endif; ?>
                    }],
                    language: {
                        <?php if(!app('mobile-detect')->isMobile()) : ?>
                        search: "Pencarian",
                        <?php endif; ?>
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        search: "",
                        searchPlaceholder: "Pencarian",
                        <?php endif; ?>
                        info: "Menampilkan data ke _START_ sampai _END_ dari _TOTAL_ total data",
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    }
                });
                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                })
            });
        </script>

        <?php if($errors->any()): ?>
            <script type="text/javascript">
                Swal.fire({
                    title: 'Ops...',
                    html: 'Ada sesuatu yang salah.<br>Pastikan form sudah terisi semua dengan benar.',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#fa5c7c'
                })
            </script>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4)): ?>
<?php $component = $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4; ?>
<?php unset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/superadmin/pernyataanterakhirpd.blade.php ENDPATH**/ ?>