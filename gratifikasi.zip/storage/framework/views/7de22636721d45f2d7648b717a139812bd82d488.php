<?php if (isset($component)) { $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminwideLayout::class, []); ?>
<?php $component->withName('superadminwide-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .file-custom {
                padding-top: 2.4rem !important;
                padding-bottom: 2.3rem !important;
                padding-left: 1.8rem !important;
            }

            .file-custom:focus {
                outline: none;
            }

        </style>
        <?php if(!app('mobile-detect')->isMobile()) : ?>
        <style>
            table.dataTable>tbody>tr.child span.dtr-title {
                min-width: 180px !important;
                max-width: 700px !important;
            }

        </style>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__(' Dashboard Superadmin - Pencarian Pegawai')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.pegawai')); ?>">Data Pegawai</a></li>
        <li class="breadcrumb-item active">Pencarian</li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Pegawai')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Hasil pencarian pegawai dengan <?php echo e($key[0]); ?>

                            <?php echo e($key[1]); ?></h4>

                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        <th data-priority="2" width="1%">#</th>
                                        <th data-priority="0">Nama</th>
                                        <th>NIP</th>
                                        <th>No. HP</th>
                                        
                                        <th>Jabatan</th>
                                        <th>Pangkat/golongan</th>
                                        <th>Satker</th>
                                        <th>Perangkat Daerah</th>
                                        <th data-priority="1" class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php ($i = 1); ?>
                                        <?php $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($i++); ?></td>
                                                <td><?php echo e($d->name); ?></td>
                                                <td><?php echo e(konversiNIP($d->nip)); ?></td>
                                                <td>
                                                    <a href="https://wa.me/62<?php echo e(substr($d->phone, 1)); ?>?text=Halo Ibu/Bapak <?php echo e($d->name); ?>"
                                                        target="_blank" class="text-black-50">
                                                        <?php echo e($d->phone); ?>

                                                    </a>
                                                </td>
                                                
                                                <td><?php echo e($d->jabatan); ?></td>
                                                <td><?php echo e($d->pangkat); ?></td>
                                                <td><?php echo e($d->satker); ?></td>
                                                <td><?php echo e($d->pd); ?></td>
                                                <td class="text-center">
                                                    <button type="button" class="btn btn-success btn-xsm ebutton"
                                                        data-quantity="<?php echo e($d->id); ?>|<?php echo e($d->name); ?>|<?php echo e($d->nip); ?>|<?php echo e($d->email); ?>|<?php echo e($d->phone); ?>|<?php echo e($d->pd); ?>|<?php echo e($d->satker); ?>"
                                                        data-bs-toggle="modal" data-bs-target="#edit">
                                                        <i class="uil-pen"></i> <?php if(!app('mobile-detect')->isMobile()) : ?> edit <?php endif; ?>
                                                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> edit <?php endif; ?>
                                                    </button>

                                                    <button type="button" class="btn btn-info btn-xsm pbutton"
                                                        data-quantity="<?php echo e($d->id); ?>|<?php echo e($d->name); ?>|<?php echo e($d->nip); ?>"
                                                        data-bs-toggle="modal" data-bs-target="#pass">
                                                        <i class="uil-key-skeleton"></i> <?php if(!app('mobile-detect')->isMobile()) : ?> password <?php endif; ?>
                                                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> pass <?php endif; ?>
                                                    </button>

                                                    <button type="button" class="btn btn-danger btn-xsm dbutton"
                                                        data-quantity="<?php echo e($d->id); ?>|<?php echo e($d->name); ?>|<?php echo e($d->nip); ?>"
                                                        data-bs-toggle="modal" data-bs-target="#del">
                                                        <i class="uil-trash-alt"></i> <?php if(!app('mobile-detect')->isMobile()) : ?> hapus <?php endif; ?>
                                                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> del <?php endif; ?>
                                                    </button>
                                                    <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                                                    <script>
                                                        $('.pbutton').click(function() {
                                                            var data = $(this).data('quantity').split('|');
                                                            $('#p-id').val(data[0]);
                                                            $('#p-name').val(data[1]);
                                                            $('#p-nip').val(data[2]);
                                                            $('#password').val('');
                                                            $('#confirmPassword').val('');
                                                        });

                                                        $('.dbutton').click(function() {
                                                            var data = $(this).data('quantity').split('|');
                                                            $('.d-id').val(data[0]);
                                                            $('.d-name').val(data[1]);
                                                            $('.d-nip').val(data[2]);
                                                            $('.d-file').val('');
                                                        });

                                                        $('.ebutton').click(function() {
                                                            var data = $(this).data('quantity').split('|');
                                                            $('.e-id').val(data[0]);
                                                            $('.e-name').val(data[1]);
                                                            $('.e-nip').val(data[2]);
                                                            $('.e-email').val(data[3]);
                                                            $('.e-phone').val(data[4]);
                                                            $('.e-pd').val(data[5]);
                                                            $('.e-satker').val(data[6]);
                                                        });

                                                    </script>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php echo $__env->make('components.superadmin.modal.pegawai-search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.superadmin.modal.pegawai-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.superadmin.modal.pegawai-del', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.superadmin.modal.pegawai-password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.superadmin.modal.pegawai-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

         <?php $__env->endSlot(); ?>

         <?php $__env->slot('script', null, []); ?> 
            <script>
                $(document).ready(function() {
                    "use strict";
                    var a = $("#datatable-buttons").DataTable({
                        order: [
                            [0, 'asc']
                        ],
                        lengthChange: !1,
                        filter: !1,
                        searching: 1,
                        pageLength: 20,
                        info: !0,
                        buttons: [{
                                <?php if(!app('mobile-detect')->isMobile()) : ?>
                                text: '<i class="uil-arrow-left"></i>Kembali',
                                <?php endif; ?>
                                <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                                text: '<i class="uil-arrow-left"></i>',
                                className: 'mb-1',
                                <?php endif; ?>
                                action: function(e, dt, node, config) {
                                    window.open(
                                        "<?php echo e(route('superadmin.pegawai')); ?>",
                                        "_self");
                                }
                            },
                            {
                                <?php if(!app('mobile-detect')->isMobile()) : ?>
                                text: '<i class="mdi mdi-account-search"></i> Pencarian Pegawai',
                                className: 'searchbt',
                                <?php endif; ?>
                                <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                                text: '<i class="mdi mdi-account-search"></i>',
                                className: 'mb-1 searchbt',
                                <?php endif; ?>
                            },
                            {
                                extend: 'colvis',
                                <?php if(!app('mobile-detect')->isMobile()) : ?>
                                text: 'Kolom',
                                className: 'btn-rounded-e',
                                <?php endif; ?>
                                <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                                text: '<i class="mdi mdi-table-eye"></i>',
                                className: 'mb-1',
                                <?php endif; ?>
                            },
                        ],
                        language: {
                            lengthMenu: "Menampilkan _MENU_ pegawai per halaman",
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            search: "Pencarian",
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            search: "",
                            searchPlaceholder: "Pencarian",
                            <?php endif; ?>
                            info: "Menampilkan data ke _START_ sampai _END_ dari _TOTAL_ total data",
                            infoFiltered: "(dari total _MAX_ data)",
                            infoEmpty: "Data tidak ditemukan",
                            paginate: {
                                previous: "<i class='mdi mdi-chevron-left'>",
                                next: "<i class='mdi mdi-chevron-right'>"
                            }
                        },
                        drawCallback: function() {
                            $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                            $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                                "bg-secondary");
                        }
                    });
                    a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                        "#alternative-page-datatable").DataTable({
                        pagingType: "full_numbers",
                        drawCallback: function() {
                            $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                        }
                    });
                    a.buttons('.searchbt')
                        .nodes()
                        .attr('data-bs-toggle', 'modal');
                    a.buttons('.searchbt')
                        .nodes()
                        .attr('data-bs-target', '#search');
                });

            </script>
            <?php if(!app('mobile-detect')->isMobile()) : ?>
            <script>
                $('.pbutton').click(function() {
                    var data = $(this).data('quantity').split('|');
                    $('#p-id').val(data[0]);
                    $('#p-name').val(data[1]);
                    $('#p-nip').val(data[2]);
                    $('#password').val('');
                    $('#confirmPassword').val('');
                });

                $('.dbutton').click(function() {
                    var data = $(this).data('quantity').split('|');
                    $('.d-id').val(data[0]);
                    $('.d-name').val(data[1]);
                    $('.d-nip').val(data[2]);
                    $('.d-file').val('');
                });

                $('.ebutton').click(function() {
                    var data = $(this).data('quantity').split('|');
                    $('.e-id').val(data[0]);
                    $('.e-name').val(data[1]);
                    $('.e-nip').val(data[2]);
                    $('.e-email').val(data[3]);
                    $('.e-phone').val(data[4]);
                    $('.e-pd').val(data[5]);
                    $('.e-satker').val(data[6]);
                });

            </script>
            <?php endif; ?>


            <?php if($errors->any()): ?>
                <script type="text/javascript">
                    Swal.fire({
                        title: 'Ops...',
                        html: 'Ada sesuatu yang salah.<br>Pastikan form sudah terisi semua dengan benar.',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#fa5c7c'
                    })

                </script>
            <?php endif; ?>
            <script>
                function success() {
                    if (document.getElementById("name").value === "" && document.getElementById("nip" === "")) {
                        document.getElementById('cari').disabled = true;
                    } else {
                        document.getElementById('cari').disabled = false;
                    }
                }

                function onlyName() {
                    document.getElementById("nip").value = null;
                    document.getElementById("name").required = true;
                    document.getElementById("nip").required = false;
                }

                function onlyNip() {
                    document.getElementById("name").value = null;
                    document.getElementById("nip").required = true;
                    document.getElementById("name").required = false;
                }

            </script>
         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4)): ?>
<?php $component = $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4; ?>
<?php unset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/superadmin/pegawaipencarian.blade.php ENDPATH**/ ?>