<!DOCTYPE html>
<html data-theme="light" <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> data-layout-mode="fluid" <?php endif; ?> <?php if(!app('mobile-detect')->isMobile()) : ?> data-layout-mode="fluid" <?php endif; ?>
    data-topbar-color="light" data-sidenav-size="default" data-sidenav-color="dark" data-layout-position="fixed"
    class="menuitem-active" lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title><?php echo e($title); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>">

    <!-- datatables CSS -->
    <link href="<?php echo e(asset('datatables/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('datatables/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('datatables/buttons.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css">

    <script src="<?php echo e(asset('js/user-config.js')); ?>"></script>
    <link href="<?php echo e(asset('css/app-saas.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style">
    <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css">

    <script src="<?php echo e(asset('js/sweetalert2.js')); ?>"></script>
    <link href="<?php echo e(asset('css/sweetalert2.css')); ?>" rel="stylesheet" type="text/css">

    <?php echo e($style ?? ''); ?>

</head>

<body class="show">
    <div class="wrapper">

        <?php echo $__env->make('components.superadmin.top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="leftside-menu menuitem-active">
            
            <?php echo $__env->make('components.user.logo-fluid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.superadmin.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="content-page">
            <div class="content">

                <div class="container-fluid">

                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <?php echo e($breadcrumb); ?>

                                    </ol>
                                </div>
                                <h4 class="page-title"><?php echo e($header); ?></h4>
                            </div>
                        </div>
                    </div>

                    <?php echo e($content); ?>


                </div>

            </div>

        </div>
    </div>
    <script src="<?php echo e(asset('js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
    <!-- datatables JS -->
    <script src="<?php echo e(asset('datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/buttons.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/button.jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/buttons.print.min.js')); ?>"></script>

    <?php echo e($script ?? ''); ?>


    <?php if(Session::has('success')): ?>
        <script type="text/javascript">
            Swal.fire({
                title: 'Berhasil..!',
                text: '<?php echo session('success'); ?>',
                icon: 'success',
                confirmButtonText: 'OK',
                confirmButtonColor: '#0acf97'
            })

        </script>
    <?php endif; ?>

    <?php if(Session::has('fail')): ?>
        <script type="text/javascript">
            Swal.fire({
                title: 'Ops...',
                text: '<?php echo session('fail'); ?>',
                icon: 'error',
                confirmButtonText: 'OK',
                confirmButtonColor: '#fa5c7c'
            })

        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/layouts/superadmin.blade.php ENDPATH**/ ?>