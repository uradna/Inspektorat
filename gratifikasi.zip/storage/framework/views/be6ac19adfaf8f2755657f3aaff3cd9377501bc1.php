<?php if (isset($component)) { $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminwideLayout::class, []); ?>
<?php $component->withName('superadminwide-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .file-custom {
                padding-top: 2.4rem !important;
                padding-bottom: 2.3rem !important;
                padding-left: 1.8rem !important;
            }

            .file-custom:focus {
                outline: none;
            }

        </style>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Data Pernyataan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.pernyataan')); ?>">Pernyataan</a></li>
        <li class="breadcrumb-item active">Tahun <?php echo e($jadwal->tahun); ?> Semester <?php echo e($jadwal->semester); ?></li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Pernyataan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Data Pernyataan - Tahun <?php echo e($jadwal->tahun); ?> Semester
                            <?php echo e($jadwal->semester); ?></h4>


                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        
                                        <th data-priority="3" width="1%">#</th>
                                        <th data-priority="2">Perangkat Daerah</th>
                                        <th class="text-center">
                                            Jumlah <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>pernyataan <?php endif; ?>
                                        </th>
                                        <th class="text-center">
                                            Total pegawai</sup>
                                        </th>
                                        <th class="text-center">
                                            Persentase</sup>
                                        </th>
                                        <th class="text-center">
                                            P#1</sup>
                                        </th>
                                        <th class="text-center">
                                            P#2</sup>
                                        </th>
                                        <th data-priority="1" class="text-center"> <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>Aksi <?php endif; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php ($i = 1); ?>

                                        <?php $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($i++); ?></td>
                                                <td>
                                                    <?php if(!app('mobile-detect')->isMobile()) : ?> <?php echo e($d->pd); ?> <?php else: ?>
                                                    <?php echo e(str_replace('Dinas', 'Din.', str_replace('Kecamatan', 'Kec.', str_replace('Bagian', 'Bag.', $d->pd)))); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                    <?php echo e($d->jumlah); ?>

                                                </td>
                                                <td class="text-center">
                                                    <?php echo e($d->total); ?>

                                                </td>
                                                <td class="text-center">
                                                    <?php echo e(round(($d->jumlah / $d->total) * 100, 1)); ?>%
                                                </td>
                                                <td class="text-center">
                                                    <?php echo e($d->t2); ?>

                                                </td>
                                                <td class="text-center">
                                                    <?php echo e($d->t3); ?>

                                                </td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('superadmin.pernyataan.terakhir.pd', [$d->pd])); ?>"
                                                        class="btn btn-info btn-xsm">
                                                        <i class="mdi mdi-eye"></i> <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?> Lihat <?php endif; ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div>
                                    <hr>Keterangan : <br>
                                    P#1 : Jumlah pegawai yang MENERIMA gratifikasi dan SUDAH melaporkan ke UPG/KPK<br>
                                    P#2 : Jumlah pegawai yang MENERIMA gratifikasi dan BELUM melaporkan ke UPG/KPK<br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



         <?php $__env->endSlot(); ?>

         <?php $__env->slot('script', null, []); ?> 
            <script>
                $(document).ready(function() {
                    "use strict";
                    var a = $("#datatable-buttons").DataTable({
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        columnDefs: [{
                            targets: 1,
                            render: function(data, type, row) {
                                return data.length > 20 ?
                                    data.substr(0, 20) + '…' :
                                    data;
                            }
                        }],
                        <?php endif; ?>
                        // buttons: [{
                        //     text: 'Jumlah pegawai saat ini :  pegawai',
                        //     className: 'btn btn-light pe-none',
                        //     // action: function(e, dt, node, config) {
                        //     //     window.open("https://www.w3schools.com", "_self");
                        //     // }
                        // }],

                        lengthChange: !1,
                        filter: 1,
                        // searching: 1,
                        pageLength: 10,
                        // bPaginate: !1,
                        // filter: !1,
                        info: 1,
                        buttons: [{
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            text: '<i class="uil-arrow-left"></i> Kembali',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="uil-arrow-left"></i>',
                            className: 'mb-1',
                            <?php endif; ?>
                            action: function(e, dt, node, config) {
                                window.open("<?php echo e(route('superadmin.pernyataan')); ?>", "_self");
                            }
                        }, {
                            extend: 'print',
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-printer"></i>',
                            className: 'mb-1',
                            <?php endif; ?>
                            title: 'Data Pernyataan - Tahun <?php echo e($jadwal->tahun); ?> Semester <?php echo e($jadwal->semester); ?>',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4]
                            }
                        }, {
                            extend: 'excel',
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-microsoft-excel"></i>',
                            className: 'mb-1',
                            <?php endif; ?>
                            title: 'Data Pernyataan - Tahun <?php echo e($jadwal->tahun); ?> Semester <?php echo e($jadwal->semester); ?>',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4]
                            }
                        }, {
                            extend: 'colvis',
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            text: 'Kolom',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-table-eye"></i>',
                            className: 'mb-1',
                            <?php endif; ?>
                        }],
                        language: {
                            // lengthMenu: "Menampilkan _MENU_ pegawai per halaman",
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            search: "Pencarian",
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            search: "",
                            searchPlaceholder: "Pencarian",
                            <?php endif; ?>
                            info: "Menampilkan data ke _START_ sampai _END_ dari _TOTAL_ total data",
                            paginate: {
                                previous: "<i class='mdi mdi-chevron-left'>",
                                next: "<i class='mdi mdi-chevron-right'>"
                            }
                        },
                        drawCallback: function() {
                            $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                            $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                                "bg-secondary");
                        }
                    });
                    a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                        "#alternative-page-datatable").DataTable({
                        pagingType: "full_numbers",
                        drawCallback: function() {
                            $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                        }
                    })
                });

            </script>



            

            

            

            <?php if($errors->any()): ?>
                <script type="text/javascript">
                    Swal.fire({
                        title: 'Ops...',
                        html: 'Ada sesuatu yang salah.<br>Pastikan form sudah terisi semua dengan benar.',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#fa5c7c'
                    })

                </script>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4)): ?>
<?php $component = $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4; ?>
<?php unset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/superadmin/pernyataanterakhir.blade.php ENDPATH**/ ?>