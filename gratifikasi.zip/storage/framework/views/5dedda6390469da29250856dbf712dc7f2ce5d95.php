<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\prakom\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>