<!DOCTYPE html>
<html data-theme="light" data-layout-mode="detached" data-topbar-color="light" data-sidenav-size="default"
    data-sidenav-color="dark" data-layout-position="fixed" class="menuitem-active" lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Gratifikasi Online</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- App favicon -->
    <link rel="shortcut icon" href="files/favicon.png">

    <!-- Theme Config Js -->
    <script src="<?php echo e(asset('js/hyper-config.js')); ?>"></script>

    <!-- App css -->
    <link href="<?php echo e(asset('css/app-saas.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style">

    <!-- Icons css -->
    <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
</head>

<body class="show">
    <!-- Begin page -->
    <div class="wrapper">


        <!-- ========== Topbar Start ========== -->
        <div class="navbar-custom topnav-navbar">
            <div class="container-fluid detached-nav">
                <div class="logo-topbar">
                    <!-- Logo light -->
                    <a href="#" class="logo-light">
                        <span class="logo-lg">
                            <img src="files/logo.png" alt="logo" height="50">
                        </span>
                    </a>

                    <!-- Logo Dark -->
                    <a href="#" class="logo-dark">
                        <span class="logo-lg">
                            <img src="files/logo-dark.png" alt="dark logo" height="50">
                        </span>
                    </a>
                </div>
                <!-- Sidebar Menu Toggle Button -->
                <button class="button-toggle-menu">
                    <i class="mdi mdi-menu"></i>
                </button>

                <ul class="list-unstyled topbar-menu float-end mb-0">

                    <li class="notification-list d-none d-sm-inline-block">
                        <a class="nav-link" data-bs-toggle="offcanvas" href="#theme-settings-offcanvas">
                            <i class="ri-settings-3-line noti-icon"></i>
                        </a>
                    </li>

                    <li class="dropdown notification-list">
                        <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#"
                            role="button" aria-haspopup="false" aria-expanded="false">
                            <span class="account-user-avatar">
                                <img src="files/white.jpg" alt="user-image" class="rounded-circle">
                            </span>
                            <span>
                                <span class="account-user-name">Andaru Krido Utomo</span>
                                <span class="account-position">19860524 202012 1 004</span>
                            </span>
                        </a>
                        <div
                            class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">

                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item">
                                <i class="mdi mdi-account-circle me-1"></i>
                                <span>My Account</span>
                            </a>

                            <!-- item-->
                            <a href="javascript:void(0);" class="dropdown-item notify-item">
                                <i class="mdi mdi-logout me-1"></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </li>
                </ul>

            </div>
        </div>
        <!-- ========== Topbar End ========== -->

        <!-- ========== Left Sidebar Start ========== -->
        <div class="leftside-menu menuitem-active">

            <!-- Logo Light -->
            <a href="#" class="logo logo-light">
                <span class="logo-lg">
                    <img src="files/logo.png" alt="logo" height="50">
                </span>
                <span class="logo-sm">
                    <img src="files/logo-sm.png" alt="small logo" height="40">
                </span>
            </a>

            <!-- Sidebar -left -->
            <div class="h-100 show" id="leftside-menu-container" data-simplebar="init">
                <div class="simplebar-wrapper" style="margin: 0px;">
                    <div class="simplebar-mask">
                        <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                            <div class="simplebar-content-wrapper" tabindex="0" role="region"
                                aria-label="scrollable content" style="height: 100%; overflow: hidden scroll;">
                                <div class="simplebar-content" style="padding: 0px;padding-top: 10px;">
                                    <!-- Leftbar User -->


                                    <!--- Sidemenu -->
                                    <ul class="side-nav">
                                        <li class="side-nav-title side-nav-item">Navigation</li>
                                        <li class="side-nav-item">
                                            <a href="dashboard.html" class="side-nav-link">
                                                <i class="uil-home-alt"></i>
                                                <span> Dashboards </span>
                                            </a>
                                        </li>
                                        <li class="side-nav-item">
                                            <a href="pernyataan.html" class="side-nav-link">
                                                <i class="uil-file-edit-alt"></i>
                                                <span> Surat Pernyataan </span>
                                            </a>
                                        </li>
                                        <li class="side-nav-item">
                                            <a href="list.html" class="side-nav-link">
                                                <i class="uil-file-edit-alt"></i>
                                                <span> Daftar Jadwal </span>
                                            </a>
                                        </li>
                                        <li class="side-nav-item">
                                            <a href="daftar.html" class="side-nav-link">
                                                <i class="uil-newspaper"></i>
                                                <span> Laporan Gratifikasi </span>
                                            </a>
                                        </li>

                                        <li class="side-nav-title side-nav-item"> </li>
                                        <li class="side-nav-title side-nav-item">Setting</li>

                                        <li class="side-nav-item">
                                            <a href="form.html" class="side-nav-link">
                                                <i class="uil-key-skeleton"></i>
                                                <span> Password </span>
                                            </a>
                                        </li>

                                        <li class="side-nav-item">
                                            <a href="#" class="side-nav-link">
                                                <i class="uil-exit"></i>
                                                <span> Logout </span>
                                            </a>
                                        </li>

                                    </ul>


                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="simplebar-placeholder" style="width: auto; height: 2453px;"></div>
                </div>
                <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                    <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>
                </div>
                <div class="simplebar-track simplebar-vertical" style="visibility: visible;">
                    <div class="simplebar-scrollbar"
                        style="height: 167px; transform: translate3d(0px, 350px, 0px); display: block;"></div>
                </div>
            </div>
        </div>
        <!-- ========== Left Sidebar End ========== -->

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <!-- <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Hyper</a></li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Base UI</a></li>
                                        <li class="breadcrumb-item active">Typography</li>
                                    </ol>
                                </div> -->
                                <h4 class="page-title">Dashboard</h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card bg-alternative text-white">
                                <div class=" card-body">
                                    <h4 class="header-title">Selamat datang, <i>Andaru Krido Utomo!</i></h4>

                                    Anda login sebagai penggguna.<br /><br />

                                    <div class="alert bg-dark text-white border-0" role="alert">
                                        <strong>Perhatian - </strong> Pengisian surat pernyataaan gratifikasi Semester 2
                                        Tahun 2022
                                        dibuka hingga 25 Februari 2023. <a href="#">Klik di sini</a> untuk mengisi surat
                                        pernyataan.
                                    </div>

                                    Untuk informasi dan bantuan, silakan hubungi kanal berikut:<br />
                                    <i class="uil-phone"></i> 0352 – 2557 8448<br />
                                    <i class="uil-envelope "></i> inspektorat@ponorogo.go.id

                                </div> <!-- end card-body -->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->



                    <div class="row">
                        <div class="col-12">
                            <div class="card ">
                                <div class=" card-body">
                                    <h4 class="header-title mb-3">Data pengisian surat pernyataan</h4>

                                    <div class="table-responsive">
                                        <table class="table mb-0 table-sm">
                                            <thead class="bg-lighter">
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Tahun</th>
                                                    <th scope="col">Semester</th>
                                                    <th scope="col">Tanggal</th>
                                                    <th scope="col">Status</th>
                                                    <th scope="col">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>2022</td>
                                                    <td>2</td>
                                                    <td>2 Jan 2023 - 20 Feb 2023</td>
                                                    <td>Belum Mengisi</td>
                                                    <td><a href="#" class="btn btn-success btn-xsm"><i
                                                                class="uil-pen"></i>
                                                            Isi
                                                            pernyataan</a></td>
                                                </tr>
                                                <tr>
                                                    <td>2</td>
                                                    <td>2022</td>
                                                    <td>1</td>
                                                    <td>8 Sep 2022 - 20 Oct 2022</td>
                                                    <td>Tidak Mengisi</td>
                                                    <td>-</td>
                                                </tr>
                                                <tr>
                                                    <td>3</td>
                                                    <td>2021</td>
                                                    <td>2</td>
                                                    <td>15 Feb 2022 - 20 Mar 2022</td>
                                                    <td>Mengisi</td>
                                                    <td><a href="#" class="btn btn-info btn-xsm"><i
                                                                class="uil-print"></i> Cetak</a></td>
                                                </tr>
                                                <tr>
                                                    <td>4</td>
                                                    <td>2021</td>
                                                    <td>1</td>
                                                    <td>8 Sep 2021 - 20 Oct 201</td>
                                                    <td>Mengisi</td>
                                                    <td><a href="#" class="btn btn-info btn-xsm"><i
                                                                class="uil-print"></i> Cetak</a></td>
                                                </tr>



                                            </tbody>
                                        </table>
                                    </div>
                                </div> <!-- end card-body -->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div>
                </div> <!-- container -->

            </div> <!-- content -->

            <!-- Footer Start -->
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8">
                            Inspektorat Ponorogo bekerja sama dengan Dinas Komunikasi Informatika dan Statistik Ponorogo
                        </div>

                    </div>
                </div>
            </footer>
            <!-- end Footer -->

        </div>

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->

    </div>
    <!-- END wrapper -->

    <!-- Theme Settings -->
    <div class="offcanvas offcanvas-end border-0" tabindex="-1" id="theme-settings-offcanvas">
        <div class="offcanvas-body p-0">
            <div data-simplebar="init" class="h-100">
                <div class="simplebar-wrapper" style="margin: 0px;">
                    <div class="simplebar-height-auto-observer-wrapper">
                        <div class="simplebar-height-auto-observer"></div>
                    </div>
                    <div class="simplebar-mask">
                        <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                            <div class="simplebar-content-wrapper" tabindex="0" role="region"
                                aria-label="scrollable content" style="height: 100%; overflow: hidden scroll;">
                                <div class="simplebar-content" style="padding: 0px;">
                                    <div class="card mb-0 p-3">
                                        <div id="layout-width">
                                            <h5 class="my-3 font-16 fw-bold">Layout Mode</h5>

                                            <div class="row">
                                                <div class="col-4">
                                                    <div class="form-check card-radio">
                                                        <input class="form-check-input" type="radio"
                                                            name="data-layout-mode" id="layout-mode-fluid" value="fluid"
                                                            checked="checked">
                                                        <label class="form-check-label p-0 avatar-md w-100"
                                                            for="layout-mode-fluid">

                                                        </label>
                                                    </div>
                                                    <h5 class="font-14 text-center text-muted mt-2">Fluid</h5>
                                                </div>


                                                <div class="col-4" id="layout-detached">
                                                    <div class="form-check sidebar-setting card-radio">
                                                        <input class="form-check-input" type="radio"
                                                            name="data-layout-mode" id="data-layout-detached"
                                                            value="detached">
                                                        <label class="form-check-label p-0 avatar-md w-100"
                                                            for="data-layout-detached">


                                                        </label>
                                                    </div>
                                                    <h5 class="font-14 text-center text-muted mt-2">Detached</h5>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- Vendor js -->
    <script src="files/vendor.min.js"></script>

    <!-- Code Highlight js -->
    <script src="files/hyper-syntax.js"></script>

    <!-- App js -->
    <script src="files/app.min.js"></script>



</body>

</html>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/components/client.blade.php ENDPATH**/ ?>