<?php if (isset($component)) { $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminLayout::class, []); ?>
<?php $component->withName('superadmin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Gratifikasi Online')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">

                <div class="card bg-secondary text-white">
                    <div class=" card-body">
                        <h4 class="header-title">Selamat datang, <i><?php echo e(Auth::user()->name); ?></i></h4>

                        Anda login sebagai <b class="text-warning"> Superadmin <?php echo e(Auth::user()->pd); ?></b><br /><br />

                        Untuk informasi dan bantuan <a href="<?php echo e(route('bantuan')); ?>" class="text-warning"><b>klik
                                di sini</b></a>, atau hubungi kontak person Kominfo berikut:<br />
                        <i class="uil-phone"></i> 081225181060 (Andaru)<br />
                        <i class="uil-envelope "></i> andaru@ponorogo.go.id

                    </div>
                </div>


            </div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <?php if(Auth::user()->name == null): ?>)
            <script type="text/javascript">
                Swal.fire({
                    title: 'Selamat datang!',
                    html: 'Anda login untuk yang pertama kali.<br>Update data diri anda sebelum melanjutkan pengisian.', //<br><a href="<?php echo e(route('user.account')); ?>">Klik di sini</a> untuk mengupdate data diri.
                    icon: 'info',
                    // showConfirmButton: false,
                    allowOutsideClick: false,
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#39afd1'
                }).then(function() {
                    window.location = "<?php echo e(route('user.account')); ?>";
                });

            </script>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923)): ?>
<?php $component = $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923; ?>
<?php unset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/superadmin/index.blade.php ENDPATH**/ ?>