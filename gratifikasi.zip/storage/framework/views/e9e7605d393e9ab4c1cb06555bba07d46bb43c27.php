<footer class="footer footer-alt font-10">
    Inspektorat Kabupaten Ponorogo<br>
    bekerja sama dengan<br>
    Dinas Komunikasi Informatika dan Statistik Kabupaten Ponorogo
</footer>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/components/guest-footer.blade.php ENDPATH**/ ?>