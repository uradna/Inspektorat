<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Admin - Gratifikasi Online')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Dashboard Admin')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">

                <div class="card bg-secondary text-white">
                    <div class=" card-body">
                        <h4 class="header-title">Selamat datang, <i><?php echo e(Auth::user()->name); ?></i></h4>

                        Anda login sebagai <b class="text-warning"> Admin <?php echo e(Auth::user()->pd); ?></b><br /><br />

                        Untuk informasi dan bantuan <a href="<?php echo e(route('bantuan')); ?>" class="text-warning"><b>klik
                                di sini</b></a>, atau hubungi kanal berikut:<br />
                        <i class="uil-phone"></i> 0352 – 2557 8448<br />
                        <i class="uil-envelope "></i> inspektorat@ponorogo.go.id

                    </div>
                </div>


            </div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <?php if(Auth::user()->name == null): ?>)
            <script type="text/javascript">
                Swal.fire({
                    title: 'Selamat datang!',
                    html: 'Anda login untuk yang pertama kali.<br>Update data diri anda sebelum melanjutkan pengisian.', //<br><a href="<?php echo e(route('user.account')); ?>">Klik di sini</a> untuk mengupdate data diri.
                    icon: 'info',
                    // showConfirmButton: false,
                    allowOutsideClick: false,
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#39afd1'
                }).then(function() {
                    window.location = "<?php echo e(route('user.account')); ?>";
                });

            </script>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/admin/index.blade.php ENDPATH**/ ?>