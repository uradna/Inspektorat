<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .file-custom {
                padding-top: 2.4rem !important;
                padding-bottom: 2.3rem !important;
                padding-left: 1.8rem !important;
            }

            .file-custom:focus {
                outline: none;
            }
        </style>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Admin Gratifikasi Online - Data Pernyataan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Jadwal Pernyataan</li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Pernyataan - ' . Auth::user()->pd)); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Data Jadwal Pernyataan</h4>
                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        <th data-priority="3" width="1%">#</th>
                                        <th data-priority="0">Tahun</th>
                                        <th data-priority="4">Semester</th>
                                        <th>Dibuka hingga</th>
                                        <th>Status pengisian</th>
                                        <th data-priority="2">
                                            Total <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>pernyataan <?php endif; ?>
                                        </th>
                                        <th data-priority="1" class="text-center"> <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>Aksi <?php endif; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php ($i = 1); ?>
                                    <?php if($aktif != null): ?>
                                        <?php $__currentLoopData = $aktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($i++); ?></td>
                                                <td><?php echo e($a->tahun); ?></td>
                                                <td>Semester <?php echo e($a->semester); ?></td>
                                                <td><?php echo e(konversiTanggalPendek($a->akhir)); ?></td>
                                                <td>
                                                    <?php if(masihBuka($a->akhir)): ?>
                                                        Masih berlangsung
                                                    <?php else: ?>
                                                        Sudah berakhir
                                                    <?php endif; ?>
                                                    <sup class="bg-danger ms-1 text-white rounded" style="padding:0.1em 0.6em; font-size:0.6rem;"><b>!</b></sup>
                                                </td>
                                                <td><b><?php echo e($a->jumlah); ?></b> /
                                                    <?php echo e(round(($a->jumlah / $total_pegawai) * 100, 1)); ?>%
                                                </td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('admin.pernyataan.latest', $a->id)); ?>"
                                                        class="btn btn-info btn-xsm">
                                                        <i class="mdi mdi-eye"></i> <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?> lihat <?php endif; ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($i++); ?></td>
                                            <td><?php echo e($d->jadwal->tahun); ?></td>
                                            <td>Semester <?php echo e($d->jadwal->semester); ?></td>
                                            <td><?php echo e(konversiTanggalPendek($d->jadwal->akhir)); ?></td>
                                            <td>Sudah ditutup</td>
                                            <td><b><?php echo e($d->jumlah); ?></b> /
                                                <?php echo e(round(($d->jumlah / $d->total) * 100, 1)); ?>%
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('admin.pernyataan.detail', [$d->jadwal->id, $d->jadwal->tahun, $d->jadwal->semester])); ?>"
                                                    class="btn btn-info btn-xsm">
                                                    <i class="mdi mdi-eye"></i> <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?> lihat <?php endif; ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    lengthChange: !1,
                    filter: 1,
                    pageLength: 10,
                    info: !0,
                    buttons: [{
                        extend: 'print',
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        text: '<i class="mdi mdi-printer"></i>',
                        className: 'mb-1',
                        <?php endif; ?>
                        title: 'Data Pernyataan - <?php echo e(Auth::user()->pd); ?>',
                    }, {
                        extend: 'excel',
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        text: '<i class="mdi mdi-microsoft-excel"></i>',
                        className: 'mb-1',
                        <?php endif; ?>
                        title: 'Data Pernyataan Tahun - <?php echo e(Auth::user()->pd); ?>',
                    }, {
                        extend: 'colvis',
                        <?php if(!app('mobile-detect')->isMobile()) : ?>
                        text: 'Kolom',
                        <?php endif; ?>
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        text: '<i class="mdi mdi-table-eye"></i>',
                        className: 'mb-1',
                        <?php endif; ?>
                    }],
                    language: {
                        <?php if(!app('mobile-detect')->isMobile()) : ?>
                        search: "Pencarian",
                        <?php endif; ?>
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        search: "",
                        searchPlaceholder: "Pencarian",
                        <?php endif; ?>
                        info: "Menampilkan data ke _START_ sampai _END_ dari _TOTAL_ total data",
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    }
                });
                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                })
            });
        </script>

        <?php if($errors->any()): ?>
            <script type="text/javascript">
                Swal.fire({
                    title: 'Ops...',
                    html: 'Ada sesuatu yang salah.<br>Pastikan form sudah terisi semua dengan benar.',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#fa5c7c'
                })
            </script>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/admin/pernyataan.blade.php ENDPATH**/ ?>