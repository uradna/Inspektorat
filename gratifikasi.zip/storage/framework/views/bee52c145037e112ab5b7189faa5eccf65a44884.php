<?php if (isset($component)) { $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminLayout::class, []); ?>
<?php $component->withName('superadmin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .file-custom {
                padding-top: 2.4rem !important;
                padding-bottom: 2.3rem !important;
                padding-left: 1.8rem !important;
            }

            .file-custom:focus {
                outline: none;
            }

        </style>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Data Pernyataan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Pernyataan</li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Pernyataan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Data Jadwal Pernyataan</h4>


                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        
                                        <th width="1%">#</th>
                                        <th data-priority="0">Tahun</th>
                                        <th data-priority="2">Dibuka hingga</th>
                                        <th class="text-center">
                                            Jumlah <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>pernyataan <?php endif; ?>
                                        </th>
                                        <th class="text-center">
                                            Total pegawai</sup>
                                        </th>
                                        <th class="text-center">
                                            Persentase</sup>
                                        </th>
                                        <th data-priority="1" class="text-center"> Aksi </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php ($i = 1); ?>

                                        <?php if($jadwal != '0'): ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($i++); ?></td>
                                                <td><?php echo e($jadwal->tahun); ?> / Semester <?php echo e($jadwal->semester); ?></td>
                                                <td><?php echo e(konversiTanggal($jadwal->akhir)); ?></td>
                                                <td class="text-center"> <?php echo e($jadwal->pernyataan); ?> </td>
                                                <td class="text-center"> <?php echo e($jadwal->totalPegawai); ?> </td>
                                                <td class="text-center">
                                                    <?php echo e(round(($jadwal->pernyataan / $jadwal->totalPegawai) * 100, 1)); ?>%
                                                </td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('superadmin.pernyataan.terakhir')); ?>"
                                                        class="btn btn-info btn-xsm">
                                                        <i class="mdi mdi-eye"></i> <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?> Lihat <?php endif; ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endif; ?>

                                        <?php $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($i++); ?></td>
                                                <td><?php echo e($d->jadwal->tahun); ?> / Semester <?php echo e($d->jadwal->semester); ?></td>
                                                <td><?php echo e(konversiTanggal($d->jadwal->akhir)); ?></td>
                                                <td class="text-center">
                                                    <?php echo e($d->jumlah); ?>

                                                </td>
                                                <td class="text-center">
                                                    <?php echo e($d->total); ?>

                                                </td>
                                                <td class="text-center">
                                                    <?php echo e(round(($d->jumlah / $d->total) * 100, 1)); ?>%
                                                </td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('superadmin.pernyataan.jadwal', [$d->jadwal_id])); ?>"
                                                        class="btn btn-info btn-xsm">
                                                        <i class="mdi mdi-eye"></i> <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?> Lihat <?php endif; ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



         <?php $__env->endSlot(); ?>

         <?php $__env->slot('script', null, []); ?> 
            <script>
                $(document).ready(function() {
                    "use strict";
                    var a = $("#datatable-buttons").DataTable({

                        // buttons: [{
                        //     text: 'Jumlah pegawai saat ini :  pegawai',
                        //     className: 'btn btn-light pe-none',
                        //     // action: function(e, dt, node, config) {
                        //     //     window.open("https://www.w3schools.com", "_self");
                        //     // }
                        // }],

                        lengthChange: !1,
                        filter: 1,
                        // searching: 1,
                        pageLength: 10,
                        // bPaginate: !1,
                        // filter: !1,
                        info: !1,
                        buttons: [{
                            extend: 'print',
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-printer"></i>',
                            className: 'mb-1',
                            <?php endif; ?>
                            title: 'Data Pernyataan - Semua',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5]
                            }
                        }, {
                            extend: 'excel',
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-microsoft-excel"></i>',
                            className: 'mb-1',
                            <?php endif; ?>
                            title: 'Data Pernyataan - Semua',
                            exportOptions: {
                                columns: [0, 1, 2, 3, 4, 5]
                            }
                        }, {
                            extend: 'colvis',
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            text: 'Kolom',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-table-eye"></i>',
                            className: 'mb-1',
                            <?php endif; ?>
                        }],
                        language: {
                            // lengthMenu: "Menampilkan _MENU_ pegawai per halaman",
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            search: "Pencarian",
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            search: "",
                            searchPlaceholder: "Pencarian",
                            <?php endif; ?>
                            // info: "Menampilkan data ke _START_ sampai _END_ dari _TOTAL_ total data",
                            paginate: {
                                previous: "<i class='mdi mdi-chevron-left'>",
                                next: "<i class='mdi mdi-chevron-right'>"
                            }
                        },
                        drawCallback: function() {
                            $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                            $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                                "bg-secondary");
                        }
                    });
                    a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                        "#alternative-page-datatable").DataTable({
                        pagingType: "full_numbers",
                        drawCallback: function() {
                            $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                        }
                    })
                });

            </script>



            

            

            

            <?php if($errors->any()): ?>
                <script type="text/javascript">
                    Swal.fire({
                        title: 'Ops...',
                        html: 'Ada sesuatu yang salah.<br>Pastikan form sudah terisi semua dengan benar.',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#fa5c7c'
                    })

                </script>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923)): ?>
<?php $component = $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923; ?>
<?php unset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/superadmin/pernyataan.blade.php ENDPATH**/ ?>