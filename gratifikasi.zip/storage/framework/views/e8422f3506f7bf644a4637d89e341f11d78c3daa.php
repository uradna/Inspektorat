<?php if (isset($component)) { $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminwideLayout::class, []); ?>
<?php $component->withName('superadminwide-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <script src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
        <style>
            .ck.ck-content:not(.ck-comment__input *) {
                height: 300px;
                overflow-y: auto;
            }

            .ck-rounded-corners .ck.ck-editor__main>.ck-editor__editable {

                color: black !important;
            }

        </style>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Bantuan Baru')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Bantuan Baru</li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Bantuan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Buat Bantuan Baru
                        </h4>


                        <div class="modal-body">
                            <form class="needs-validation" novalidate="" method="POST"
                                action="<?php echo e(route('superadmin.help.update')); ?>">

                                <div>
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary mb-1">
                                        <i class="uil-arrow-left"></i> Kembali
                                    </a>

                                    <button type="submit" class="btn btn-success mb-1 float-end">
                                        <i class="mdi mdi-content-save"></i> Simpan
                                    </button>
                                </div>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">

                                <div class="row">
                                    <div class="position-relative mb-2 col-md-9">
                                        <div class="form-floating">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-float','data' => ['id' => __('judul'),'type' => 'text','value' => ''.e($data->judul).'','required' => true]]); ?>
<?php $component->withName('input-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('judul')),'type' => 'text','value' => ''.e($data->judul).'','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.invalid','data' => ['value' =>  __('Judul harus diisi')]]); ?>
<?php $component->withName('invalid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute( __('Judul harus diisi'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label-float','data' => ['value' => __('Judul / Pertanyaan')]]); ?>
<?php $component->withName('label-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Judul / Pertanyaan'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="position-relative mb-2 col-md-3 form-floating">
                                        <div class="form-floating">
                                            <select class="form-select" id="floatingSelect"
                                                aria-label="Floating label select example" name="for">
                                                <option <?php if($data->for == 'user'): ?> selected <?php endif; ?> value="user">User Pegawai
                                                </option>
                                                <option <?php if($data->for == 'admin'): ?> selected <?php endif; ?> value="admin">User Admin
                                                </option>
                                                <option <?php if($data->for == 'superadmin'): ?> selected <?php endif; ?> value="superadmin">User
                                                    Superadmin</option>
                                            </select>
                                            <label for="floatingSelect">Bantuan untuk</label>
                                        </div>
                                    </div>

                                    <div class="position-relative mb-2 col-md-12">
                                        <div class="">
                                            <textarea name="isi" id="isi" placeholder="Isi bantuan" required>
                                            <?php echo e($data->isi); ?>

                                            </textarea>
                                        </div>
                                    </div>

                                </div>
                            </form>
                            <script>
                                ClassicEditor
                                    .create(document.querySelector('#isi'), {
                                        // removePlugins: ['Heading', 'Table', 'MediaEmbed', 'Indent'],
                                        toolbar: ['bold', 'italic', '|', 'numberedList',
                                            'bulletedList', '|', 'blockQuote', 'link', '|', 'undo', 'redo'
                                        ]
                                    })
                                    .catch(error => {
                                        console.error(error);
                                    });

                            </script>
                        </div>


                    </div>
                </div>
            </div>
        </div>


     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 


     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4)): ?>
<?php $component = $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4; ?>
<?php unset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/superadmin/bantuan-edit.blade.php ENDPATH**/ ?>