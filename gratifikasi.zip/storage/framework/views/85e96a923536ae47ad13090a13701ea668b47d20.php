<?php if (isset($component)) { $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminLayout::class, []); ?>
<?php $component->withName('superadmin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .file-custom {
                padding-top: 2.4rem !important;
                padding-bottom: 2.3rem !important;
                padding-left: 1.8rem !important;
            }

            .file-custom:focus {
                outline: none;
            }

        </style>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Edit Banner')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Edit banner</li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Edit Banner Login')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Daftar Banner </h4>
                        <div>
                            <button type="button" class="btn btn-success mb-1" data-bs-toggle="modal"
                                data-bs-target="#new">
                                <i class="mdi mdi-plus-circle me-2"></i> Tambah Banner
                            </button>
                        </div>
                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped mb-0 dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        <th style="width:2%">#</th>
                                        <th data-priority="0">File</th>
                                        <th data-priority="2">Tampil</th>
                                        <th>Waktu</th>
                                        <th data-priority="1" class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i + 1); ?></td>
                                            <td>
                                                <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> <?php echo e(shortLink($d->img, 23, 10, 5)); ?> <?php endif; ?>
                                                <?php if(!app('mobile-detect')->isMobile()) : ?> <?php echo e(shortLink($d->img, 50, 30, 5)); ?> <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($d->aktif == 1): ?>
                                                    Ya
                                                <?php else: ?>
                                                    Tidak
                                                <?php endif; ?>
                                            </td>
                                            <td> <?php echo e($d->time); ?> detik</td>
                                            <td class="text-center">
                                                <form action="<?php echo e(route('superadmin.banner.delete')); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="button" class="btn btn-info btn-xsm pbutton"
                                                        data-quantity="<?php echo e($d->id); ?>|<?php echo e($d->img); ?>"
                                                        data-bs-toggle="modal" data-bs-target="#pdf">
                                                        <i class="mdi mdi-eye"></i>
                                                        <?php if(!app('mobile-detect')->isMobile()) : ?> preview <?php endif; ?>
                                                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> lihat <?php endif; ?>

                                                    </button>
                                                    <button type="button" class="btn btn-success btn-xsm ebutton"
                                                        data-quantity="<?php echo e($d->id); ?>|<?php echo e($d->time); ?>|<?php echo e($d->aktif); ?>|<?php echo e($d->img); ?>"
                                                        data-bs-toggle="modal" data-bs-target="#edit">
                                                        <i class="uil-pen"></i>
                                                        edit
                                                    </button>
                                                    
                                                    <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                                                    <button class="btn btn-danger btn-xsm yes_alert" type="submit">
                                                        <i class="uil-trash-alt"></i>
                                                        <?php if(!app('mobile-detect')->isMobile()) : ?> hapus <?php endif; ?>
                                                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> del <?php endif; ?>
                                                    </button>
                                                </form>

                                                <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                                                
                                                <script>
                                                    $('.pbutton').click(function() {
                                                        var data = $(this).data('quantity').split('|');
                                                        $('#preview').attr('src', '../upload/' + data[1]);
                                                    });
                                                    //
                                                    $('.ebutton').click(function() {
                                                        var data = $(this).data('quantity').split('|');
                                                        $('#idx').val(data[0]);
                                                        $('.timex').val(data[1]);
                                                        $('#namafile').val(data[3]);
                                                    });
                                                    // 
                                                    $('.yes_alert').on('click', function(e) {
                                                        e.preventDefault();
                                                        var form = $(this).parents('form');
                                                        Swal.fire({
                                                            title: 'Anda yakin?',
                                                            text: "File gambar banner akan dihapus dan tidak tampil kembali.",
                                                            icon: 'warning',
                                                            iconColor: '#fa5c7c',
                                                            showCancelButton: true,
                                                            confirmButtonColor: '#39afd1',
                                                            cancelButtonColor: '#dadee2',
                                                            confirmButtonText: 'Ya, hapus!!',
                                                            cancelButtonText: 'Batal',
                                                            reverseButtons: true
                                                        }).then((result) => {
                                                            if (result.value) {

                                                                form.submit();
                                                            }
                                                        });
                                                    });

                                                </script>
                                                
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <?php echo $__env->make('components.superadmin.modal.img_preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.superadmin.modal.banner-new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.superadmin.modal.banner-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    lengthChange: !1,
                    searching: 1,
                    pageLength: 10,
                    // bPaginate: !1,
                    // filter: !1,
                    // info: !1,
                    sDom: '<"top">rt<"bottom"l>p<"clear">',
                    //buttons: ["copy", "print", "excel"],
                    //buttons: ["print", "excel","colvis"],
                    // buttons: [{
                    //     extend: 'print'
                    // }, {
                    //     extend: 'excel'
                    // }, {
                    //     extend: 'colvis',
                    //     text: 'Kolom'
                    // }],
                    order: [
                        [0, "asc"]
                    ],
                    columnDefs: [{
                        targets: [0],
                        visible: true
                    }, {
                        targets: [2],
                        visible: true
                    }, {
                        targets: [3],
                        visible: true
                    }],
                    language: {
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    }
                });
                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                })
            });

        </script>

        <?php if($errors->any()): ?>
            <script type="text/javascript">
                $(window).on('load', function() {
                    $('#new').modal('show');
                    $('#newform').addClass('was-validated')
                });

            </script>
        <?php endif; ?>

        <?php if(!app('mobile-detect')->isMobile()) : ?> 
        <script>
            $('.pbutton').click(function() {
                var data = $(this).data('quantity').split('|');
                $('#preview').attr('src', '../upload/' + data[1]);
            });
            //
            $('.ebutton').click(function() {
                var data = $(this).data('quantity').split('|');
                $('#idx').val(data[0]);
                $('.timex').val(data[1]);
                $('#namafile').val(data[3]);
            });
            // 
            $('.yes_alert').on('click', function(e) {
                e.preventDefault();
                var form = $(this).parents('form');
                Swal.fire({
                    title: 'Anda yakin?',
                    text: "File gambar banner akan dihapus dan tidak tampil kembali.",
                    icon: 'warning',
                    iconColor: '#fa5c7c',
                    showCancelButton: true,
                    confirmButtonColor: '#39afd1',
                    cancelButtonColor: '#dadee2',
                    confirmButtonText: 'Ya, hapus!!',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {

                        form.submit();
                    }
                });
            });

        </script>
        
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923)): ?>
<?php $component = $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923; ?>
<?php unset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/superadmin/banner.blade.php ENDPATH**/ ?>