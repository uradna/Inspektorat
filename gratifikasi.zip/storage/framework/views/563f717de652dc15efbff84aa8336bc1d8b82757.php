<?php if (isset($component)) { $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminLayout::class, []); ?>
<?php $component->withName('superadmin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Jadwal')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Jadwal</li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Jadwal Pengisian')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Daftar Jadwal </h4>
                        <?php if(jadwalStatus($aktif->status)): ?>
                            <div class="alert alert-primary alert-dismissible bg-dark text-white border-0 fade show"
                                role="alert">
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                                <strong class="font-16">Perhatian!</strong><br>
                                Pengisian surat pernyataaan gratifikasi
                                <b class="text-warning">Tahun <?php echo e($aktif->tahun); ?> Semester
                                    <?php echo e($aktif->semester); ?></b>
                                dibuka hingga tanggal<b class="text-warning">
                                    <?php echo e(konversiTanggal($aktif->akhir)); ?></b>.<br>

                                Jadwal pengisian dapat ditambah jika jadwal pengisian terakhir sudah ditutup.
                                <br class="mb-1">
                            </div>
                        <?php endif; ?>

                        <div>
                            <button type="button" class="btn btn-success mb-1" data-bs-toggle="modal"
                                data-bs-target="#new" <?php if(jadwalStatus($aktif->status)): ?> disabled <?php endif; ?>>
                                <i class="mdi mdi-plus-circle me-2"></i> Tambah Jadwal
                            </button>
                        </div>
                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped mb-0 dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        <th style="width:2%">#</th>
                                        <th data-priority="0">Tahun</th>
                                        <th data-priority="2">Dibuka hingga</th>
                                        <th>Status</th>
                                        <th data-priority="1">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i + 1); ?></td>
                                            <td><?php echo e($d->tahun); ?> /
                                                <?php if(!app('mobile-detect')->isMobile()) : ?> Semester <?php endif; ?>
                                                <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> smt <?php endif; ?>
                                                <?php echo e($d->semester); ?>

                                            </td>
                                            <td>
                                                
                                                <?php echo e(konversiTanggalPendek($d->akhir)); ?>

                                                
                                            </td>
                                            <td>
                                                <?php if(masihBuka($d->akhir)): ?>
                                                    Berlangsung
                                                <?php else: ?>
                                                    <?php if(jadwalStatus($d->status)): ?>
                                                        Berakhir
                                                    <?php else: ?>
                                                        Sudah ditutup
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if(jadwalStatus($d->status)): ?>
                                                    <form action="<?php echo e(route('superadmin.jadwal.close')); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="button" class="btn btn-success btn-xsm "
                                                            data-bs-toggle="modal" data-bs-target="#new">
                                                            <i class="uil-pen"></i>
                                                            Edit
                                                        </button>
                                                        
                                                        <button class="btn btn-danger btn-xsm delete_alert"
                                                            type="submit">
                                                            <i class="uil-folder-lock"></i>
                                                            Tutup
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('superadmin.pernyataan.jadwal', [$d->id])); ?>"
                                                        class="btn btn-info btn-xsm">
                                                        <i class="mdi mdi-eye"></i>
                                                        Lihat
                                                    </a>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <?php if(!jadwalStatus($aktif->status)): ?>
            <div class="modal fade" id="new" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                aria-hidden="true" data-bs-backdrop="static">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myLargeModalLabel">
                                Tambah jadwal baru
                            </h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"
                                id="disp"></button>
                        </div>
                        <div class="modal-body">
                            <form class="needs-validation <?php if($errors->any()): ?> was-validated <?php endif; ?>" novalidate="" method="POST"
                                action="<?php echo e(route('superadmin.jadwal.create')); ?>">
                                <?php echo csrf_field(); ?>

                                
                                <div class="row">
                                    <div class="position-relative mb-2 col-md-6">
                                        <div class="form-floating">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-float','data' => ['id' => 'tahun','type' => 'text','value' => ''.e($aktif->tahun_baru).'','pattern' => '\d{4}','required' => true]]); ?>
<?php $component->withName('input-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'tahun','type' => 'text','value' => ''.e($aktif->tahun_baru).'','pattern' => '\d{4}','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.invalid','data' => ['value' => __('Tahun harus diisi')]]); ?>
<?php $component->withName('invalid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Tahun harus diisi'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label-float','data' => ['value' => __('Tahun')]]); ?>
<?php $component->withName('label-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Tahun'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="position-relative mb-2 col-md-6">
                                        <div class="form-floating">
                                            <select class="form-select text-dark" name="semester" required>

                                                <option value="1" <?php if(old('semester') != null && old('pangkat') == 1): ?> selected <?php elseif(old('pangkat') == null && $aktif->semester_baru == 1 ): ?> selected <?php endif; ?>>
                                                    1 (satu)
                                                </option>
                                                <option value="2" <?php if(old('semester') != null && old('pangkat') == 2): ?> selected <?php elseif(old('pangkat') == null && $aktif->semester_baru == 2 ): ?> selected <?php endif; ?>>
                                                    2 (dua)
                                                </option>

                                            </select>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.invalid','data' => ['value' => __('Semester harus dipilih')]]); ?>
<?php $component->withName('invalid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Semester harus dipilih'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label-float','data' => ['value' => __('Semester')]]); ?>
<?php $component->withName('label-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Semester'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row ">
                                    <div class="position-relative mb-2 col-md-12">
                                        <div class="form-floating input-group input-group-merge">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-float','data' => ['id' => __('akhir'),'type' => 'date','min' => ''.e(date('Y-m-d')).'','value' => ''.e(old('akhir') ?? '').'','required' => true]]); ?>
<?php $component->withName('input-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('akhir')),'type' => 'date','min' => ''.e(date('Y-m-d')).'','value' => ''.e(old('akhir') ?? '').'','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.invalid','data' => ['value' => __('Tanggal harus dipilih')]]); ?>
<?php $component->withName('invalid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Tanggal harus dipilih'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label-float','data' => ['value' => __('Dibuka hingga'),'style' => 'z-index: 5 !important;']]); ?>
<?php $component->withName('label-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dibuka hingga')),'style' => 'z-index: 5 !important;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row g-2 mt-1">
                                    <div class="col-md-12 text-end">
                                        <button type="button" class="btn btn-lighter me-2"
                                            data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-info">
                                            SIMPAN
                                        </button>
                                    </div>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if(jadwalStatus($aktif->status)): ?>
            <div class="modal fade" id="new" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                aria-hidden="true" data-bs-backdrop="static">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myLargeModalLabel">
                                Edit jadwal
                            </h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"
                                id="disp"></button>
                        </div>

                        <div class="modal-body">
                            <form class="needs-validation <?php if($errors->any()): ?> was-validated <?php endif; ?>" novalidate="" method="POST"
                                action="<?php echo e(route('superadmin.jadwal.edit')); ?>">
                                <?php echo csrf_field(); ?>
                                
                                <div class="row">
                                    <div class="position-relative mb-2 col-md-6">
                                        <div class="form-floating">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-float','data' => ['type' => 'text','value' => ''.e($aktif->tahun).'','disabled' => true,'readonly' => true]]); ?>
<?php $component->withName('input-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','value' => ''.e($aktif->tahun).'','disabled' => true,'readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label-float','data' => ['value' => __('Tahun')]]); ?>
<?php $component->withName('label-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Tahun'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="position-relative mb-2 col-md-6">
                                        <div class="form-floating">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-float','data' => ['type' => 'text','value' => ''.e($aktif->semester).'','disabled' => true,'readonly' => true]]); ?>
<?php $component->withName('input-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'text','value' => ''.e($aktif->semester).'','disabled' => true,'readonly' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label-float','data' => ['value' => __('Semester')]]); ?>
<?php $component->withName('label-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Semester'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row ">
                                    <div class="position-relative mb-2 col-md-12">
                                        <div class="form-floating input-group input-group-merge">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-float','data' => ['id' => __('akhir'),'type' => 'date','min' => ''.e(date('Y-m-d')).'','value' => ''.e(old('akhir') ?? $aktif->akhir).'','required' => true]]); ?>
<?php $component->withName('input-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('akhir')),'type' => 'date','min' => ''.e(date('Y-m-d')).'','value' => ''.e(old('akhir') ?? $aktif->akhir).'','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.invalid','data' => ['value' => __('Tanggal harus dipilih')]]); ?>
<?php $component->withName('invalid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Tanggal harus dipilih'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label-float','data' => ['value' => __('Dibuka hingga'),'style' => 'z-index: 5 !important;']]); ?>
<?php $component->withName('label-float'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dibuka hingga')),'style' => 'z-index: 5 !important;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row g-2 mt-1">
                                    <div class="col-md-12 text-end">
                                        <button type="button" class="btn btn-lighter me-2"
                                            data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-info">
                                            SIMPAN
                                        </button>
                                    </div>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    lengthChange: !1,
                    searching: 1,
                    pageLength: 10,
                    // bPaginate: !1,
                    // filter: !1,
                    // info: !1,
                    sDom: '<"top">rt<"bottom"l>p<"clear">',
                    //buttons: ["copy", "print", "excel"],
                    //buttons: ["print", "excel","colvis"],
                    // buttons: [{
                    //     extend: 'print'
                    // }, {
                    //     extend: 'excel'
                    // }, {
                    //     extend: 'colvis',
                    //     text: 'Kolom'
                    // }],
                    order: [
                        [1, "desc"]
                    ],
                    columnDefs: [{
                        targets: [0],
                        visible: true
                    }, {
                        targets: [2],
                        visible: true
                    }, {
                        targets: [3],
                        visible: true
                    }],
                    language: {
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    }
                });
                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                })
            });

        </script>

        <?php if($errors->any()): ?>
            <script type="text/javascript">
                $(window).on('load', function() {
                    $('#new').modal('show');
                });

            </script>
        <?php endif; ?>

        <script>
            $('.delete_alert').on('click', function(e) {
                e.preventDefault();
                var form = $(this).parents('form');
                Swal.fire({
                    title: 'Anda yakin?',
                    text: "Jadwal yang ditutup tidak bisa dibuka kembali!",
                    icon: 'warning',
                    iconColor: '#fa5c7c',
                    showCancelButton: true,
                    confirmButtonColor: '#39afd1',
                    cancelButtonColor: '#dadee2',
                    confirmButtonText: 'Ya, Tutup!!',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {

                        form.submit();
                    }
                });
            });

        </script>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923)): ?>
<?php $component = $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923; ?>
<?php unset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/superadmin/jadwal.blade.php ENDPATH**/ ?>