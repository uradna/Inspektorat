<?php if (isset($component)) { $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminLayout::class, []); ?>
<?php $component->withName('superadmin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Jadwal')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Jadwal</li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Jadwal Pengisian')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Daftar Jadwal </h4>
                        <?php if(jadwalStatus($aktif->status)): ?>
                            <div class="alert alert-primary alert-dismissible bg-dark text-white border-0 fade show"
                                role="alert">
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                                <strong class="font-16">Perhatian!</strong><br>
                                Pengisian surat pernyataaan gratifikasi
                                <b class="text-warning">Tahun <?php echo e($aktif->tahun); ?> Semester
                                    <?php echo e($aktif->semester); ?></b>
                                dibuka hingga tanggal<b class="text-warning">
                                    <?php echo e(konversiTanggal($aktif->akhir)); ?></b>.<br>

                                Jadwal pengisian dapat ditambah jika jadwal pengisian terakhir sudah ditutup.
                                <br class="mb-1">
                            </div>
                        <?php endif; ?>

                        <div>
                            <button type="button" class="btn btn-success mb-1" data-bs-toggle="modal"
                                
                                data-bs-target="#new">
                                <i class="mdi mdi-plus-circle me-2"></i> Tambah Jadwal
                            </button>
                        </div>
                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped mb-0 dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        
                                        <th data-priority="0">Tahun</th>
                                        <th data-priority="2">Dibuka hingga</th>
                                        <th>Status</th>
                                        <th data-priority="1">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td>

                                                <?php echo e($d->tahun); ?> /
                                                <?php if(!app('mobile-detect')->isMobile()) : ?>
                                                    Semester
                                                <?php endif; ?>
                                                <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                                                    smt
                                                <?php endif; ?>
                                                <?php echo e($d->semester); ?>

                                            </td>
                                            <td>
                                                
                                                <?php echo e(konversiTanggalPendek($d->akhir)); ?>

                                                
                                            </td>
                                            <td>
                                                <?php if(masihBuka($d->akhir)): ?>
                                                    Berlangsung
                                                <?php else: ?>
                                                    <?php if(jadwalStatus($d->status)): ?>
                                                        Berakhir
                                                    <?php else: ?>
                                                        Sudah ditutup
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if(jadwalStatus($d->status)): ?>
                                                    <form action="<?php echo e(route('superadmin.jadwal.close')); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="button" class="btn btn-success btn-xsm btn_edit"
                                                            data-bs-toggle="modal" data-bs-target="#edit"
                                                            data-id="<?php echo e($d->id); ?>"
                                                            data-akhir="<?php echo e($d->akhir); ?>"
                                                            data-tahun="<?php echo e($d->tahun); ?>"
                                                            data-semester="<?php echo e($d->semester); ?>">
                                                            <i class="uil-pen"></i>
                                                            Edit
                                                        </button>
                                                        
                                                        <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                                                        <button class="btn btn-danger btn-xsm delete_alert"
                                                            type="submit">
                                                            <i class="uil-folder-lock"></i>
                                                            Tutup
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('superadmin.pernyataan.jadwal', [$d->id])); ?>"
                                                        class="btn btn-info btn-xsm">
                                                        <i class="mdi mdi-eye"></i>
                                                        Lihat
                                                    </a>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        
        <?php echo $__env->make('components.superadmin.modal.jadwal-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        <?php echo $__env->make('components.superadmin.modal.jadwal-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    lengthChange: !1,
                    searching: 1,
                    pageLength: 10,
                    // bPaginate: !1,
                    // filter: !1,
                    // info: !1,
                    sDom: '<"top">rt<"bottom"l>p<"clear">',
                    //buttons: ["copy", "print", "excel"],
                    //buttons: ["print", "excel","colvis"],
                    // buttons: [{
                    //     extend: 'print'
                    // }, {
                    //     extend: 'excel'
                    // }, {
                    //     extend: 'colvis',
                    //     text: 'Kolom'
                    // }],
                    order: [
                        [0, "desc"]
                    ],
                    columnDefs: [{
                        targets: [0],
                        visible: true
                    }, {
                        targets: [2],
                        visible: true
                    }, {
                        targets: [3],
                        visible: true
                    }],
                    language: {
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    }
                });
                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                });

                a.on('click', '.btn_edit', function(e) {
                    // <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                    // let id = $(this).closest('tr').attr('id');
                    // <?php else: ?>
                    // let id = $(this).closest('tr').prev().attr('id');
                    // <?php endif; ?>
                    // let all_data = a.rows().data();
                    // let result = $.grep(all_data, function(e) {
                    //     return e.DT_RowId == id;
                    // });
                    // let data = result[0];

                    $('#e-id').val($(this).data('id'));
                    $('#eakhir').val($(this).data('akhir'));
                    $('#etahun').val($(this).data('tahun'));
                    $('#esemester').val($(this).data('semester'));
                    // $('.e-name').val(data['name']);
                    // $('.e-nip').val(data['nip']);
                    // $('.e-email').val(data['email']);
                    // $('.e-phone').val(data['phone']);
                    // $('.e-pd').val(data['pd']);
                    // $('.e-satker').val(data['satker']);
                    // alert($(this).data('id'));
                    // alert($(this).data('id'));
                });
            });
        </script>

        <?php if($errors->any()): ?>
            <script type="text/javascript">
                $(window).on('load', function() {
                    <?php if(old('eakhir')): ?>
                        $('#edit').modal('show');
                    <?php else: ?>
                        $('#new').modal('show');
                    <?php endif; ?>

                });
            </script>
        <?php endif; ?>

        <script>
            $('.delete_alert').on('click', function(e) {
                e.preventDefault();
                var form = $(this).parents('form');
                Swal.fire({
                    title: 'Anda yakin?',
                    text: "Jadwal yang ditutup tidak bisa dibuka kembali!",
                    icon: 'warning',
                    iconColor: '#fa5c7c',
                    showCancelButton: true,
                    confirmButtonColor: '#39afd1',
                    cancelButtonColor: '#dadee2',
                    confirmButtonText: 'Ya, Tutup!!',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {

                        form.submit();
                    }
                });
            });
        </script>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923)): ?>
<?php $component = $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923; ?>
<?php unset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/superadmin/jadwal.blade.php ENDPATH**/ ?>