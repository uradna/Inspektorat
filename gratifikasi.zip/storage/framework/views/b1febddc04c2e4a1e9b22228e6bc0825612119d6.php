<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>">
    
    <link href="<?php echo e(asset('css/app-saas.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style">
    <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
</head>

<body class="authentication-bg pb-0">
    <div class="auth-fluid">
        <?php echo e($slot); ?>


    </div>
    <script src="<?php echo e(asset('js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/layouts/guest.blade.php ENDPATH**/ ?>