<?php if (isset($component)) { $__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserLayout::class, []); ?>
<?php $component->withName('user-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Gratifikasi Online - Pernyataan Gratifikasi')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Pernyataan Gratifikasi')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Data pengisian surat pernyataan </h4>
                        <?php if($aktif != '0'): ?>
                            <div class="alert alert-primary alert-dismissible bg-dark text-white border-0 fade show"
                                role="alert">
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                                <strong class="font-16">Perhatian!</strong><br>
                                Pengisian surat pernyataaan gratifikasi
                                <b class="text-warning">Tahun <?php echo e($aktif->tahun); ?> Semester
                                    <?php echo e($aktif->semester); ?></b>
                                dibuka hingga tanggal<b class="text-warning">
                                    <?php echo e(konversiTanggal($aktif->akhir)); ?></b>.<br class="mb-1">
                            </div>
                        <?php endif; ?>

                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped mb-0 dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        
                                        <th data-priority="1">Tahun</th>
                                        <th data-priority="3">Dibuka hingga</th>
                                        <th>Status</th>
                                        <th data-priority="2">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td><?php echo e($d->tahun); ?> /
                                                <?php if(!app('mobile-detect')->isMobile()) : ?>
                                                    Semester
                                                <?php endif; ?>
                                                <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                                                    smt
                                                <?php endif; ?>
                                                <?php echo e($d->semester); ?>

                                            </td>
                                            <td>
                                                <?php if(masihBuka($d->akhir)): ?>
                                                    <?php echo e(konversiTanggalPendek($d->akhir)); ?>

                                                <?php else: ?>
                                                    Sudah ditutup
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e(statusJadwal($d->status)); ?></td>
                                            <td>
                                                <?php switch($d->status):
                                                    case ('0'): ?>
                                                        -
                                                    <?php break; ?>

                                                    <?php case ('1'): ?>
                                                        <a href="<?php echo e(route('user.pdf', $d->pernyataan_id)); ?>"
                                                            class="btn btn-info btn-xsm">
                                                            <i class="uil-down-arrow"></i>
                                                            PDF </a>
                                                        
                                                    <?php break; ?>

                                                    <?php case ('2'): ?>
                                                        <a href="<?php echo e(route('user.pernyataan.biodata', $d->id)); ?>"
                                                            class="btn btn-success btn-xsm"> <i class="uil-pen"></i>
                                                            Isi pernyataan </a>
                                                    <?php break; ?>

                                                    <?php case ('3'): ?>
                                                        -
                                                    <?php break; ?>
                                                <?php endswitch; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    lengthChange: !1,
                    searching: 1,
                    pageLength: 10,
                    // bPaginate: !1,
                    // filter: !1,
                    // info: !1,
                    sDom: '<"top">rt<"bottom"l>p<"clear">',
                    //buttons: ["copy", "print", "excel"],
                    //buttons: ["print", "excel","colvis"],
                    // buttons: [{
                    //     extend: 'print'
                    // }, {
                    //     extend: 'excel'
                    // }, {
                    //     extend: 'colvis',
                    //     text: 'Kolom'
                    // }],
                    order: [
                        [0, "desc"]
                    ],
                    columnDefs: [{
                        targets: [0],
                        visible: true
                    }, {
                        targets: [2],
                        visible: true
                    }, {
                        targets: [3],
                        visible: true
                    }],
                    language: {
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    }
                });
                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                })
            });
        </script>


     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107)): ?>
<?php $component = $__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107; ?>
<?php unset($__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/user/daftar.blade.php ENDPATH**/ ?>