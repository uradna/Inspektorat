<a href="<?php echo e(route('home')); ?>" class="logo logo-light">
    <span class="logo-lg">
        <img src=" <?php echo e(asset('img/logo.png')); ?> " alt="logo" height="50">
    </span>
    <span class="logo-sm">
        <img src=" <?php echo e(asset('img/logo-sm.png')); ?> " alt="small logo" height="40">
    </span>
</a>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/components/user/logo-fluid.blade.php ENDPATH**/ ?>