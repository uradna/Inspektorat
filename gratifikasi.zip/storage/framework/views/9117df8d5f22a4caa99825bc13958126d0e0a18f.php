<div class="modal fade" id="pdf" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header border-bottom-0 mb-0 pb-1">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true" id="disp"></button>
            </div>
            <div class="modal-body" style="padding-top: 6px;">
                <div class="row" style="margin-top:0px !important;">
                    
                    <div class="position-relative col-md-12 text-center">
                        <img id="preview" src="" class="img-fluid">
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/components/superadmin/modal/img_preview.blade.php ENDPATH**/ ?>