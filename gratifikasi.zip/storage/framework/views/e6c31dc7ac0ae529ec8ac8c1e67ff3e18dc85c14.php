<div class="navbar-custom topnav-navbar">
    <div class="container-fluid detached-nav">

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.user.logo-detached','data' => []]); ?>
<?php $component->withName('user.logo-detached'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <button class="button-toggle-menu">
            <i class="mdi mdi-menu"></i>
        </button>

        <ul class="list-unstyled topbar-menu float-end mb-0">

            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#"
                    role="button" aria-haspopup="false" aria-expanded="false">
                    <span class="account-user-avatar">
                        <img src="<?php echo e(asset('img/user-m.png')); ?>" alt="user-image" class="rounded-circle">
                    </span>
                    <span>
                        <span class="account-user-name"><?php echo e(Auth::user()->name ?? '-'); ?></span>
                        <span class="account-position"><?php echo e(Auth::user()->pd); ?></span>
                    </span>
                </a>
                <div
                    class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>

                        
                        
                        


                        <a href="<?php echo e(route('admin.account')); ?>" class="dropdown-item notify-item">
                            <i class="mdi mdi-account-circle me-1"></i>
                            <span>Kelola akun</span>
                        </a>
                        <a class="dropdown-item notify-item pointer" onclick="event.preventDefault();
                        this.closest('form').submit();"
                            role="button" target="_blank">
                            <i class="mdi mdi-logout me-1"></i>
                            <span>Logout</span>
                        </a>
                    </form>
                </div>
            </li>
        </ul>

    </div>
</div>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/components/admin/top-bar.blade.php ENDPATH**/ ?>