<?php if (isset($component)) { $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminLayout::class, []); ?>
<?php $component->withName('superadmin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Pegawai')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Data Pegawai</li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Pegawai')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Daftar Perangkat Daerah </h4>


                        
                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped mb-0 dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        <th data-priority="3" style="width:2%">#</th>
                                        <th data-priority="0">Perangkat Daerah</th>
                                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> <th>Nama</th> <?php endif; ?>

                                        <th class="text-center">Jumlah Pegawai</th>
                                        <th data-priority="1" class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $perangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i + 1); ?></td>
                                            <td><?php if(!app('mobile-detect')->isMobile()) : ?> <?php echo e($d->nama); ?> <?php else: ?>
                                                <?php echo e(str_replace('Dinas', 'Din.', str_replace('Kecamatan', 'Kec.', str_replace('Bagian', 'Bag.', $d->nama)))); ?>

                                                <?php endif; ?> </td>
                                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> <td><?php echo e($d->nama); ?></td> <?php endif; ?>
                                            <td class="text-center"><?php echo e($d->total); ?> </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('superadmin.pegawai.pd', $d->nama)); ?>"
                                                    class="btn btn-info btn-xsm">
                                                    <i class="mdi mdi-eye"></i>
                                                    <?php if(!app('mobile-detect')->isMobile()) : ?> Lihat <?php endif; ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('components.superadmin.modal.pegawai-search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.superadmin.modal.pegawai-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                    columnDefs: [{
                        targets: 1,
                        render: function(data, type, row) {
                            return data.length > 20 ?
                                data.substr(0, 20) + '…' :
                                data;
                        }
                    }],
                    <?php endif; ?>
                    lengthChange: !1,
                    searching: 1,
                    pageLength: 20,
                    buttons: [{
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            text: '<i class="mdi mdi-account-search"></i> Pencarian Pegawai',
                            className: 'searchbt btn-rounded-e',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-account-search"></i>',
                            className: 'mb-1 searchbt',
                            <?php endif; ?>
                        },
                        {
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            text: '<i class="mdi mdi-plus-circle me-1"></i> Tambah Pegawai',
                            className: 'add-bt ms-2 btn-rounded btn-success',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-plus-circle"></i>',
                            className: 'mb-1 add-bt btn-success',
                            <?php endif; ?>
                        },
                        // {
                        //     extend: 'collection',
                        //     text: 'Table control',
                        //     buttons: [{
                        //             text: 'Toggle start date',
                        //             action: function(e, dt, node, config) {
                        //                 window.open(
                        //                     "<?php echo e(route('superadmin.pegawai')); ?>",
                        //                     "_self");
                        //             }
                        //         },
                        //         {
                        //             text: 'Toggle salary',
                        //             action: function(e, dt, node, config) {
                        //                 window.open(
                        //                     "<?php echo e(route('superadmin.pegawai')); ?>",
                        //                     "_self");
                        //             }
                        //         }
                        //     ]
                        // }
                    ],
                    // bPaginate: !1,
                    // filter: !1,
                    info: !1,
                    // sDom: '<"top">rt<"bottom"l>p<"clear">',
                    // buttons: ["copy", "print", "excel"],
                    // buttons: ["print", "excel", "colvis"],
                    // buttons: [{
                    //     extend: 'print'
                    // }, {
                    //     extend: 'excel'
                    // }, {
                    //     extend: 'colvis',
                    //     text: 'Kolom'
                    // }],
                    order: [
                        [0, "asc"]
                    ],
                    // columnDefs: [{
                    //     targets: [0],
                    //     visible: true
                    // }, {
                    //     targets: [2],
                    //     visible: true
                    // }, {
                    //     targets: [3],
                    //     visible: true
                    // }],
                    language: {
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    language: {
                        // lengthMenu: "Menampilkan _MENU_ pegawai per halaman",
                        <?php if(!app('mobile-detect')->isMobile()) : ?>
                        search: "Pencarian",
                        <?php endif; ?>
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        search: "",
                        searchPlaceholder: "Pencarian",
                        <?php endif; ?>
                        info: "Menampilkan data ke _START_ sampai _END_ dari _TOTAL_ total data",
                        infoFiltered: "(dari total _MAX_ data)",
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    }
                });

                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                });
                a.buttons('.searchbt')
                    .nodes()
                    .attr('data-bs-toggle', 'modal');
                a.buttons('.searchbt')
                    .nodes()
                    .attr('data-bs-target', '#search');
                a.buttons('.add-bt')
                    .nodes()
                    .attr('data-bs-toggle', 'modal');
                a.buttons('.add-bt')
                    .nodes()
                    .attr('data-bs-target', '#add');
            });

        </script>

        <?php if($errors->any()): ?>
            <script type="text/javascript">
                $(window).on('load', function() {
                    $('#new').modal('show');
                });

            </script>
        <?php endif; ?>

        <script>
            $('.delete_alert').on('click', function(e) {
                e.preventDefault();
                var form = $(this).parents('form');
                Swal.fire({
                    title: 'Anda yakin?',
                    text: "Jadwal yang ditutup tidak bisa dibuka kembali!",
                    icon: 'warning',
                    iconColor: '#fa5c7c',
                    showCancelButton: true,
                    confirmButtonColor: '#39afd1',
                    cancelButtonColor: '#dadee2',
                    confirmButtonText: 'Ya, Tutup!!',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {

                        form.submit();
                    }
                });
            });

        </script>

        <script>
            function success() {
                if (document.getElementById("name").value === "" && document.getElementById("nip" === "")) {
                    document.getElementById('cari').disabled = true;
                } else {
                    document.getElementById('cari').disabled = false;
                }
            }

            function onlyName() {
                document.getElementById("nip").value = null;
                document.getElementById("name").required = true;
                document.getElementById("nip").required = false;
            }

            function onlyNip() {
                document.getElementById("name").value = null;
                document.getElementById("nip").required = true;
                document.getElementById("name").required = false;
            }

        </script>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923)): ?>
<?php $component = $__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923; ?>
<?php unset($__componentOriginalf98b4f7e094e16fdae7c1686af1ea67a3d7e2923); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/superadmin/pegawai.blade.php ENDPATH**/ ?>