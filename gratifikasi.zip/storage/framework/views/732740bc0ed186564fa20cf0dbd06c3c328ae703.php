<?php if (isset($component)) { $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SuperadminwideLayout::class, []); ?>
<?php $component->withName('superadminwide-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <script src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
        <style>
            .ck.ck-content:not(.ck-comment__input *) {
                height: 300px;
                overflow-y: auto;
            }

        </style>
        <?php if(!app('mobile-detect')->isMobile()) : ?>
        <style>
            span.dtr-title {
                display: inline-flex !important;
                min-width: 50px !important;
                vertical-align: top !important;
            }

            span.dtr-data {
                display: inline-block;
                /* max-width: 750px; */
                white-space: normal;
                padding-right: 20px;
                /* background-color: black; */
                /* word-break: normal; */

                /* word-break: normal;
                max-width: 250px; */

            }

        </style>
        <?php endif; ?>
        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
        <style>
            span.dtr-title {
                display: inline-flex !important;
                min-width: 50px !important;
                vertical-align: top !important;
            }

            span.dtr-data {
                display: inline-block;
                max-width: 250px;
                white-space: normal;
                padding-right: 20px;
            }

        </style>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Dashboard Superadmin - Edit Bantuan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Edit Bantuan</li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Bantuan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Daftar Bantuan - User <?php if($u == 'user'): ?> Pegawai <?php else: ?> <?php echo e($u); ?> <?php endif; ?>
                        </h4>

                        <div class="table-responsive">
                            <table id="datatable-buttons"
                                class="table table-striped <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?> dt-responsive nowrap w-100 <?php endif; ?> ">
                                <thead class="bg-lighter">
                                    <tr>
                                        
                                        <th data-priority="3" width="1%">#</th>
                                        <th data-priority="0" width="25%">Judul</th>
                                        <th>Isi</th>
                                        
                                        <th data-priority="1" style="width: 150px" class="text-center">Aksi</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($d->order); ?></td>
                                            
                                            <td><?php echo e($d->judul); ?></td>
                                            <td><?php echo $d->isi; ?></td>

                                            <td class="text-start">

                                                <form action="<?php echo e(route('superadmin.banner.delete')); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <a class="btn btn-success btn-xsm ebutton">
                                                        <i class="uil-pen"></i> edit

                                                    </a>

                                                    <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                                                    <button class="btn btn-danger btn-xsm yes_alert" type="submit">
                                                        <i class="uil-trash-alt"></i>
                                                        hapus
                                                    </button>
                                                </form>
                                                <?php if($d->order != 1): ?>
                                                    <a href="#up" class="btn btn-xsm btn-secondary">
                                                        <i class="uil-arrow-up"></i></a>
                                                <?php endif; ?>


                                                <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                                                <script>
                                                    $('.ebutton').click(function() {
                                                        var data = $(this).data('quantity').split('|');
                                                        $('.e-id').val(data[0]);
                                                        $('.e-name').val(data[1]);
                                                        $('.e-nip').val(data[2]);
                                                        $('.e-email').val(data[3]);
                                                        $('.e-phone').val(data[4]);
                                                        $('.e-pd').val(data[5]);
                                                        $('.e-satker').val(data[6]);
                                                    });
                                                    $('.yes_alert').on('click', function(e) {
                                                        e.preventDefault();
                                                        var form = $(this).parents('form');
                                                        Swal.fire({
                                                            title: 'Anda yakin?',
                                                            text: "File gambar banner akan dihapus dan tidak tampil kembali.",
                                                            icon: 'warning',
                                                            iconColor: '#fa5c7c',
                                                            showCancelButton: true,
                                                            confirmButtonColor: '#39afd1',
                                                            cancelButtonColor: '#dadee2',
                                                            confirmButtonText: 'Ya, hapus!!',
                                                            cancelButtonText: 'Batal',
                                                            reverseButtons: true
                                                        }).then((result) => {
                                                            if (result.value) {

                                                                form.submit();
                                                            }
                                                        });
                                                    });

                                                </script>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('components.superadmin.modal.bantuan-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.superadmin.modal.pegawai-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    order: [
                        [0, 'asc']
                    ],
                    // buttons: [{
                    //     text: 'Jumlah pegawai saat ini :  pegawai',
                    //     className: 'btn btn-light pe-none',
                    // action: function(e, dt, node, config) {
                    //     window.open("https://www.w3schools.com", "_self");
                    // }
                    // }],

                    lengthChange: !1,
                    filter: !1,
                    searching: 1,
                    pageLength: 20,
                    // bPaginate: !1,
                    // filter: !1,
                    info: !0,
                    // sDom: '<"top">rt<"bottom"l>p<"clear">',
                    //buttons: ["copy", "print", "excel"],
                    // buttons: ["print", "excel", "colvis"],
                    buttons: [{
                            extend: 'collection',
                            text: 'Bantuan Untuk',
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            className: 'btn-rounded',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            className: ' mb-1',
                            <?php endif; ?>
                            buttons: [{
                                    text: 'User Pegawai',
                                    action: function(e, dt, node, config) {
                                        window.open(
                                            "<?php echo e(route('superadmin.help', 'user')); ?>",
                                            "_self");
                                    }
                                },
                                {
                                    text: 'User Admin',
                                    action: function(e, dt, node, config) {
                                        window.open(
                                            "<?php echo e(route('superadmin.help', 'admin')); ?>",
                                            "_self");
                                    }
                                },
                                {
                                    text: 'User Superadmin',
                                    action: function(e, dt, node, config) {
                                        window.open(
                                            "<?php echo e(route('superadmin.help', 'superadmin')); ?>",
                                            "_self");
                                    }
                                },

                            ]
                        },
                        // {
                        //     extend: 'print',
                        //     <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        //     text: '<i class="mdi mdi-printer"></i>',
                        //     className: 'mb-1',
                        //     <?php endif; ?>
                        //     title: '',
                        //     exportOptions: {
                        //         columns: [0, 1, 2, 3, 4, 5, 6, 7]
                        //     }
                        // }, {
                        //     extend: 'excel',
                        //     <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        //     text: '<i class="mdi mdi-microsoft-excel"></i>',
                        //     className: 'mb-1',
                        //     <?php endif; ?>
                        //     title: '',
                        //     exportOptions: {
                        //         columns: [0, 1, 2, 3, 4, 5, 6, 7]
                        //     }
                        // }, 

                        {
                            <?php if(!app('mobile-detect')->isMobile()) : ?>
                            text: '<i class="mdi mdi-plus-circle me-1"></i> Tambah Pegawai',
                            className: 'add-bt ms-2 btn-rounded btn-success',
                            <?php endif; ?>
                            <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                            text: '<i class="mdi mdi-plus-circle"></i>',
                            className: 'mb-1 add-bt btn-success',
                            <?php endif; ?>
                            action: function(e, dt, node, config) {
                                window.open(
                                    "<?php echo e(route('superadmin.help.new')); ?>",
                                    "_self");
                            }
                        },
                    ],
                    language: {
                        lengthMenu: "Menampilkan _MENU_ pegawai per halaman",
                        <?php if(!app('mobile-detect')->isMobile()) : ?>
                        search: "Pencarian",
                        <?php endif; ?>
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        search: "",
                        searchPlaceholder: "Pencarian",
                        <?php endif; ?>
                        info: "Menampilkan data ke _START_ sampai _END_ dari _TOTAL_ total data",
                        infoFiltered: "(dari total _MAX_ data)",
                        infoEmpty: "Data tidak ditemukan",
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    }
                });
                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                });
                // a.buttons('.add-bt')
                //     .nodes()
                //     .attr('data-bs-toggle', 'modal');
                // a.buttons('.add-bt')
                //     .nodes()
                //     .attr('data-bs-target', '#add');
            });

        </script>
        <?php if(!app('mobile-detect')->isMobile()) : ?>
        <script>
            $('.ebutton').click(function() {
                var data = $(this).data('quantity').split('|');
                $('.e-id').val(data[0]);
                $('.e-name').val(data[1]);
                $('.e-nip').val(data[2]);
                $('.e-email').val(data[3]);
                $('.e-phone').val(data[4]);
                $('.e-pd').val(data[5]);
                $('.e-satker').val(data[6]);
            });
            $('.yes_alert').on('click', function(e) {
                e.preventDefault();
                var form = $(this).parents('form');
                Swal.fire({
                    title: 'Anda yakin?',
                    text: "File gambar banner akan dihapus dan tidak tampil kembali.",
                    icon: 'warning',
                    iconColor: '#fa5c7c',
                    showCancelButton: true,
                    confirmButtonColor: '#39afd1',
                    cancelButtonColor: '#dadee2',
                    confirmButtonText: 'Ya, hapus!!',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {

                        form.submit();
                    }
                });
            });

        </script>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <script type="text/javascript">
                Swal.fire({
                    title: 'Ops...',
                    html: 'Ada sesuatu yang salah.<br>Pastikan form sudah terisi semua dengan benar.',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#fa5c7c'
                })

            </script>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4)): ?>
<?php $component = $__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4; ?>
<?php unset($__componentOriginalbdacf710f6a777982b752ef5c6549066e59f8ad4); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\INSP\resources\views/superadmin/editbantuan.blade.php ENDPATH**/ ?>