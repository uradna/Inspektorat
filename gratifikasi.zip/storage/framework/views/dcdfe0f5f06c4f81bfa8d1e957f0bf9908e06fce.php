<?php if (isset($component)) { $__componentOriginalabe6fdfa8ea9beda9c9eacb5bd0ab1db4ece1aaa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminwideLayout::class, []); ?>
<?php $component->withName('adminwide-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .file-custom {
                padding-top: 2.4rem !important;
                padding-bottom: 2.3rem !important;
                padding-left: 1.8rem !important;
            }

            .file-custom:focus {
                outline: none;
            }
        </style>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Admin Gratifikasi Online - Data Pernyataan Tahun ' . $tahun . ' - Semester ' . $semester)); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a> terakhir</li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.pernyataan')); ?>">Jadwal Pernyataan</a></li>
        <li class="breadcrumb-item active">Tahun <?php echo e($tahun); ?> - Semester
            <?php echo e($semester); ?></li>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Data Pernyataan - ' . Auth::user()->pd)); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card ">
                    <div class=" card-body">
                        <h4 class="header-title mb-3">Data Pernyataan Tahun <?php echo e($tahun); ?> - Semester
                            <?php echo e($semester); ?></h4>

                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                                <thead class="bg-lighter">
                                    <tr>
                                        <th data-priority="0">Nama</th>
                                        <th data-priority="2">NIP</th>
                                        <th data-priority="4">No. HP</th>
                                        <th>Jabatan</th>
                                        <th>Satker</th>
                                        <th data-priority="1"><?php if(!app('mobile-detect')->isMobile()) : ?>Pernyataan <?php else: ?> P <?php endif; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="main">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>
    <?php
        $url = route('admin.pernyataan.ajaxLatest', [Request()->id]);
    ?>
     <?php $__env->slot('script', null, []); ?> 
        <script>
            $(document).ready(function() {
                "use strict";
                var a = $("#datatable-buttons").DataTable({
                    <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                    dom: '<"container-fluid"<"row"<"col ps-0"B><"col pe-0"f>>>rtip',
                    <?php else: ?>
                    dom: 'Bfrtip',
                    <?php endif; ?>

                    ajax: "<?php echo e($url); ?>",
                    dataSrc: 'data',
                    columnDefs: [{
                            data: 'name',
                            targets: 0
                        },
                        {
                            data: 'nip',
                            targets: 1,
                            render: function(data, type, row) {
                                return row.nip.substr(0, 8) + " " + row.nip.substr(8, 6) + " " + row.nip.substr(14, 1) + " " + row.nip.substr(15, 3);
                            }
                        },
                        {
                            data: 'phone',
                            targets: 2
                        },
                        {
                            data: 'jabatan',
                            targets: 3
                        },
                        {
                            data: 'satker',
                            targets: 4
                        },
                        {
                            data: 'pernyataan',
                            targets: 5,
                            render: function(data, type, row) {
                                if (row.pernyataan === "1") {
                                    return '<i class="mdi mdi-check btn btn-xsm btn-success pe-none fst-normal"> <?php if(!app('mobile-detect')->isMobile()) : ?>sudah <?php endif; ?> </i>';
                                } else {

                                    return '<i class="mdi mdi-close btn btn-xsm btn-danger pe-none fst-normal"> <?php if(!app('mobile-detect')->isMobile()) : ?>belum <?php endif; ?> </i>';

                                }
                            }
                        }
                    ],
                    order: [
                        [5, 'desc']
                    ],
                    lengthChange: !1,
                    searching: 1,
                    pageLength: 10,
                    info: !0,
                    buttons: [{
                        <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                        text: '<i class="uil-arrow-left"></i>Kembali',
                        <?php else: ?>
                        text: '<i class="uil-arrow-left"></i>',
                        className: 'mb-1',
                        <?php endif; ?>
                        action: function(e, dt, node, config) {
                            window.open("<?php echo e(route('admin.pernyataan')); ?>", "_self");
                        }
                    }, {
                        extend: 'excel',
                        <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                        text: '<i class="mdi mdi-microsoft-excel"></i>',
                        className: 'mb-1',
                        <?php endif; ?>
                        title: 'Data Pernyataan Tahun <?php echo e($tahun); ?> - Semester <?php echo e($semester); ?> - <?php echo e(Auth::user()->pd); ?>',
                    }, {
                        extend: 'colvis',
                        <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                        text: 'Kolom',
                        <?php else: ?>
                        text: '<i class="mdi mdi-table-eye"></i>',
                        className: 'mb-1',
                        <?php endif; ?>
                    }],
                    language: {
                        <?php if (!app('mobile-detect')->isMobile() || app('mobile-detect')->isTablet()) : ?>
                        search: "Pencarian",
                        <?php else: ?>
                        search: "",
                        searchPlaceholder: "Pencarian",
                        <?php endif; ?>
                        info: "Menampilkan data ke _START_ sampai _END_ dari _TOTAL_ total data",
                        paginate: {
                            previous: "<i class='mdi mdi-chevron-left'>",
                            next: "<i class='mdi mdi-chevron-right'>"
                        }
                    },
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded");
                        $(".dataTables_paginate > .pagination > .active > .page-link ").addClass(
                            "bg-secondary");
                    }
                });
                a.buttons().container().appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)"), $(
                    "#alternative-page-datatable").DataTable({
                    pagingType: "full_numbers",
                    drawCallback: function() {
                        $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
                    }
                })
            });
        </script>

        <?php if($errors->any()): ?>
            <script type="text/javascript">
                Swal.fire({
                    title: 'Ops...',
                    html: 'Ada sesuatu yang salah.<br>Pastikan form sudah terisi semua dengan benar.',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#fa5c7c'
                })
            </script>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabe6fdfa8ea9beda9c9eacb5bd0ab1db4ece1aaa)): ?>
<?php $component = $__componentOriginalabe6fdfa8ea9beda9c9eacb5bd0ab1db4ece1aaa; ?>
<?php unset($__componentOriginalabe6fdfa8ea9beda9c9eacb5bd0ab1db4ece1aaa); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/admin/terakhir.blade.php ENDPATH**/ ?>