<?php if (isset($component)) { $__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserLayout::class, []); ?>
<?php $component->withName('user-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Gratifikasi Online - Pernyataan')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> 
        
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Pernyataan Gratifikasi')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content', null, []); ?> 
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title mb-3">
                            Pernyataan gratifikasi periode
                            <?php echo e($periode = convertPeriode($jadwal->tahun, $jadwal->semester)); ?>

                        </h4>
                        <div class="mx-3">
                            <ul class="nav nav-pills nav-justified form-wizard-header mb-3">
                                <li class="nav-item">
                                    <a class="nav-link rounded-0 py-1">
                                        <i class="mdi mdi-account-box font-18 align-middle me-1"></i>
                                        <span class="d-none d-sm-inline">Biodata</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link rounded-0 py-1 
                                    <?php if(session('step')=='1' ): ?> active <?php endif; ?>">
                                        <i class="mdi mdi-chat-question font-18 align-middle me-1"></i>
                                        <span class="d-none d-sm-inline">Pernyataan 1</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link rounded-0 py-1 
                                    <?php if(session('step')=='2' ): ?> active <?php endif; ?>">
                                        <i class="mdi mdi-chat-question font-18 align-middle me-1"></i>
                                        <span class="d-none d-sm-inline">Pernyataan 2</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link rounded-0 py-1 
                                    <?php if(session('step')=='3' ): ?> active <?php endif; ?>">
                                        <i class="mdi mdi-chat-question font-18 align-middle me-1"></i>
                                        <span class="d-none d-sm-inline">Pernyataan 3</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link rounded-0 py-1">
                                        <i class="mdi mdi-book-edit-outline font-18 align-middle me-1"></i>
                                        <span class="d-none d-sm-inline">Laporan Gratifikasi</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content mb-0 b-0">
                            <form id="question1"
                                action="<?php echo e(route('user.post.point', [$jadwal->id, session('step')])); ?>"
                                class="form-horizontal needs-validation" novalidate="" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-12 text-center font-18 mt-2 mb-3">
                                        <?php switch(session('step')):
                                            case ('1'): ?>
                                                Apakah anda pernah menerima gratifikasi
                                                pada periode <?php echo e($periode); ?>?
                                            <?php break; ?>
                                            
                                            <?php case ('2'): ?>
                                                Apakah anda pernah menerima gratifikasi dan melaporkannya kepada UPG/KPK
                                                pada periode <?php echo e($periode); ?>?
                                            <?php break; ?>
                                            
                                            <?php case ('3'): ?>
                                                Apakah anda pernah menerima gratifikasi dan belum melaporkannya
                                                pada periode <?php echo e($periode); ?>?
                                            <?php break; ?>
                                            
                                            <?php default: ?>

                                        <?php endswitch; ?>

                                        <div class="mt-4 font-22 mb-4">
                                            <div class="form-check form-check-inline position-relative">
                                                <input type="radio" id="r1" name="p" class="form-check-input" value="1"
                                                    required <?php if(session('step') == 3 && session('pernyataan.tanya2') == 0): ?> checked <?php endif; ?>>
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.invalid','data' => ['value' => __('Pilih salah satu jawaban'),'style' => 'width:110px !important;max-width:200%;']]); ?>
<?php $component->withName('invalid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Pilih salah satu jawaban')),'style' => 'width:110px !important;max-width:200%;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                <label class="form-check-label" for="r1">YA</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" id="r2" name="p" class="form-check-input" value="0"
                                                    required <?php if(session('step') == 3 && session('pernyataan.tanya2') == 0): ?> disabled <?php endif; ?>>
                                                <label class="form-check-label" for="r2">TIDAK</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <ul class="list-inline wizard mb-0">
                                    <li class="previous list-inline-item disabled">
                                        <a href="<?php echo e(route('user.pernyataan.biodata', $jadwal->id)); ?>"
                                            class="btn btn-light">
                                            <i class="mdi mdi-arrow-left me-1"></i> Kembali
                                        </a>
                                    </li>
                                    <li class="next list-inline-item float-end ">
                                        <button type="submit" class="btn btn-info float-end">
                                            Selanjutnya <i class="mdi mdi-arrow-right ms-1"></i>
                                        </button>
                                    </li>
                                </ul>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        
        
     <?php $__env->endSlot(); ?>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107)): ?>
<?php $component = $__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107; ?>
<?php unset($__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gratifikasi\resources\views/user/point1.blade.php ENDPATH**/ ?>