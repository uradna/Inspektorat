<div class="card-header bg-dark">
    <a href="{{ route('login') }}">
        <img src="{{ asset('img/logo.png') }}" style="max-height: 40px;">
    </a>
</div>
