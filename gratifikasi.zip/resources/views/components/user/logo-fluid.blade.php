<a href="{{ route('home') }}" class="logo logo-light">
    <span class="logo-lg">
        <img src=" {{ asset('img/logo.png') }} " alt="logo" height="50">
    </span>
    <span class="logo-sm">
        <img src=" {{ asset('img/logo-sm.png') }} " alt="small logo" height="40">
    </span>
</a>
